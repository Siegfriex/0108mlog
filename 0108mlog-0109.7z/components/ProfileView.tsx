/** ⚠️ LEGACY - ProfileView | ProfileMain.tsx에서 사용 중 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Settings, Shield, MessageSquare, ChevronRight, ArrowLeft, UserCog } from 'lucide-react';
// UI 컴포넌트 import 경로: 새로운 구조로 변경
import { GlassCard } from '../src/components/ui';
import { PersonaEditor } from './PersonaEditor';
// 대화 관리 컴포넌트 import: FEAT-017
import { ConversationManager } from '../src/components/profile/ConversationManager';
import { CoachPersona, TimelineEntry } from '../types';

interface ProfileViewProps {
  persona: CoachPersona;
  onUpdatePersona: (persona: CoachPersona) => void;
  conversations?: TimelineEntry[]; // 대화 목록 (FEAT-017)
  onDeleteConversation?: (id: string) => void;
  onDeleteAllConversations?: () => void;
}

type ProfileSubView = 'main' | 'persona' | 'settings' | 'privacy' | 'conversations';

export const ProfileView: React.FC<ProfileViewProps> = ({ 
  persona, 
  onUpdatePersona,
  conversations = [],
  onDeleteConversation,
  onDeleteAllConversations,
}) => {
  const [view, setView] = useState<ProfileSubView>('main');

  const menuItems = [
    { id: 'persona', label: 'AI 페르소나 설정', icon: <UserCog size={20} />, description: 'AI 동반자 커스터마이징' },
    { id: 'settings', label: '앱 설정', icon: <Settings size={20} />, description: '알림, 테마' },
    { id: 'privacy', label: '개인정보 및 데이터', icon: <Shield size={20} />, description: '데이터 관리 및 내보내기' },
    { id: 'conversations', label: '대화 관리', icon: <MessageSquare size={20} />, description: '기록 보기, 삭제' },
  ];

  const renderContent = () => {
    switch (view) {
      case 'persona':
        return (
            <div className="h-full flex flex-col">
                <div className="flex items-center gap-2 mb-4 px-4 pt-2">
                    <button onClick={() => setView('main')} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                        <ArrowLeft size={20} className="text-slate-600" />
                    </button>
                    <h3 className="font-bold text-slate-800">프로필로 돌아가기</h3>
                </div>
                <PersonaEditor persona={persona} onUpdate={onUpdatePersona} />
            </div>
        );
      case 'settings':
        return <PlaceholderView title="앱 설정" onBack={() => setView('main')} />;
      case 'privacy':
        return <PlaceholderView title="개인정보 및 데이터" onBack={() => setView('main')} />;
      case 'conversations':
        return (
          <div className="h-full flex flex-col">
            <div className="flex items-center gap-2 mb-4 px-4 pt-2">
              <button onClick={() => setView('main')} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft size={20} className="text-slate-600" />
              </button>
              <h3 className="font-bold text-slate-800">Back to Profile</h3>
            </div>
            <ConversationManager
              conversations={conversations}
              onDeleteConversation={onDeleteConversation}
              onDeleteAll={onDeleteAllConversations}
            />
          </div>
        );
      default:
        return (
          <div className="px-4 py-6 max-w-xl mx-auto w-full h-full flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto scrollbar-hide min-h-0">
            <header className="mb-8 text-center pt-4">
                <div className="w-24 h-24 bg-gradient-to-br from-brand-secondary to-brand-primary rounded-full mx-auto mb-4 flex items-center justify-center text-white shadow-lg shadow-brand-primary/30">
                    <User size={40} strokeWidth={1.5} />
                </div>
                <h2 className="text-2xl font-bold text-slate-800">User Profile</h2>
                <div className="flex justify-center gap-2 mt-3">
                    <span className="px-3 py-1 bg-brand-light text-brand-primary rounded-full text-[10px] font-bold uppercase tracking-wider border border-brand-secondary">Level 5</span>
                    <span className="px-3 py-1 bg-orange-50 text-orange-600 rounded-full text-[10px] font-bold uppercase tracking-wider border border-orange-100">1,250 XP</span>
                </div>
            </header>

            <div className="space-y-4 pb-24">
                {menuItems.map((item) => (
                    <GlassCard 
                        key={item.id} 
                        className="!p-0 flex items-center cursor-pointer hover:bg-white/80 transition-colors group"
                        onClick={() => setView(item.id as ProfileSubView)}
                    >
                        <div className="p-5 flex items-center w-full">
                            <div className="w-12 h-12 rounded-2xl bg-brand-light flex items-center justify-center text-brand-primary mr-4 shrink-0 group-hover:bg-brand-primary group-hover:text-white transition-colors">
                                {item.icon}
                            </div>
                            <div className="flex-1">
                                <h4 className="font-bold text-slate-800 text-sm">{item.label}</h4>
                                <p className="text-slate-500 text-xs">{item.description}</p>
                            </div>
                            <ChevronRight size={20} className="text-slate-300 group-hover:text-brand-primary transition-colors" />
                        </div>
                    </GlassCard>
                ))}
            </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="h-full w-full flex flex-col overflow-hidden">
        <AnimatePresence mode="wait">
            <motion.div
                key={view}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="h-full flex flex-col overflow-hidden"
            >
                {renderContent()}
            </motion.div>
        </AnimatePresence>
    </div>
  );
};

const PlaceholderView: React.FC<{ title: string; onBack: () => void }> = ({ title, onBack }) => (
    <div className="h-full flex flex-col px-4 pt-2">
        <div className="flex items-center gap-2 mb-8 py-4">
            <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft size={20} className="text-slate-600" />
            </button>
            <h2 className="text-xl font-bold text-slate-800">{title}</h2>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 opacity-50 pb-20">
            <Settings size={48} strokeWidth={1} className="mb-4" />
            <p className="text-sm font-medium">Coming Soon in Phase 1</p>
        </div>
    </div>
);
