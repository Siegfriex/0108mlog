/**
 * 마음로그 V5.0 메인 라우터 설정
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/router/Router.tsx
 * - 역할: React Router v6 기반 라우팅 시스템 및 Provider 계층 구조 초기화
 * - 사용 위치: 0108mlog-0109/index.tsx (앱 엔트리 포인트)
 * 
 * ## Provider 계층 구조
 * ```
 * ErrorBoundary (최상위 에러 캡처)
 *   └─ AppProvider (전역 상태: mode, persona, timeline, emotion)
 *       └─ UIProvider (UI 상태: immersive, loading, isOnline)
 *           └─ BrowserRouter (React Router v6)
 *               └─ OnboardingGuard (온보딩 완료 여부 체크)
 *                   └─ Routes (라우트 정의)
 * ```
 * 
 * ## 라우트 구조
 * - `/onboarding`: OnboardingLayout (9개 온보딩 스텝)
 * - `/*`: MainLayout (메인 앱, GNB/Dock 포함)
 *   - 중첩 라우트: routes.tsx에서 27개 라우트 정의
 * - `/`: 기본 경로 → `/chat` 리다이렉트
 * 
 * ## Anonymous Auth 부트스트랩
 * - 시점: 컴포넌트 마운트 시 (useEffect)
 * - 로직: ensureAnonymousAuth() 호출
 *   - Firebase Auth 익명 로그인 시도
 *   - 재시도 로직: 최대 3회, 지수 백오프
 *   - 실패 시: 에러 로그만 출력, 앱은 계속 실행 (오프라인 모드 등)
 * - 관련 파일: 0108mlog-0109/src/services/auth.ts
 * 
 * ## 관련 파일
 * - 라우트 정의: 0108mlog-0109/src/router/routes.tsx (27개 경로)
 * - 가드: 0108mlog-0109/src/router/guards.tsx
 * - 레이아웃: 
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx
 *   - 0108mlog-0109/src/components/layout/OnboardingLayout.tsx
 * - Context:
 *   - 0108mlog-0109/src/contexts/AppContext.tsx
 *   - 0108mlog-0109/src/contexts/UIContext.tsx
 * - 에러 처리: 0108mlog-0109/src/components/ui/ErrorBoundary.tsx
 * 
 * ## 위험요인
 * - ✅ ErrorBoundary로 최상위 에러 캡처
 * - ✅ Anonymous Auth 실패 시 앱 계속 실행 (graceful degradation)
 * - ⚠️ useEffect 의존성 배열 빈 배열: 마운트 시 1회만 실행
 * - ⚠️ Provider 중첩 깊이: 4단계 (성능 영향 최소, 리렌더링 최적화 필요)
 * - ⚠️ OnboardingGuard가 모든 라우트를 감싸므로, localStorage 접근 실패 시 전체 앱 영향
 */

import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout } from '../components/layout/MainLayout';
import { OnboardingLayout } from '../components/layout/OnboardingLayout';
import { routes } from './routes';
import { OnboardingGuard } from './guards';
import { ErrorBoundary } from '../components/ui';
import { ensureAnonymousAuth } from '../services/auth';
import { AppProvider, UIProvider } from '../contexts';

/**
 * 메인 라우터 컴포넌트
 * 
 * @component
 * @returns {JSX.Element} Router 컴포넌트
 */
export const AppRouter: React.FC = () => {
  // Anonymous Auth 자동 부트스트랩
  useEffect(() => {
    ensureAnonymousAuth().catch((error) => {
      console.error('Failed to bootstrap anonymous auth:', error);
      // 인증 실패해도 앱은 계속 실행 (오프라인 모드 등)
    });
  }, []);

  return (
    <ErrorBoundary>
      <AppProvider>
        <UIProvider>
          <BrowserRouter>
            <OnboardingGuard>
              <Routes>
                {/* 온보딩 라우트 */}
                <Route path="/onboarding" element={<OnboardingLayout />} />
                
                {/* 메인 앱 라우트 */}
                <Route path="/*" element={<MainLayout />}>
                  {/* 중첩 라우트는 routes.tsx에서 정의 */}
                  {routes}
                </Route>
                
                {/* 기본 리다이렉트 */}
                <Route path="/" element={<Navigate to="/chat" replace />} />
              </Routes>
            </OnboardingGuard>
          </BrowserRouter>
        </UIProvider>
      </AppProvider>
    </ErrorBoundary>
  );
};
