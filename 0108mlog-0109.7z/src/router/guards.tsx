/**
 * 마음로그 V5.0 네비게이션 가드
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/router/guards.tsx
 * - 역할: 라우트 보호 로직 (온보딩, 인증, 프리미엄 기능)
 * - 사용 위치: 0108mlog-0109/src/router/Router.tsx
 * 
 * ## 가드 종류
 * 
 * ### 1. OnboardingGuard (현재 사용 중)
 * - 역할: 온보딩 완료 여부 확인
 * - 로직:
 *   1. localStorage에서 'onboarding_completed' 값 확인
 *   2. 미완료 + 온보딩 페이지 아님 → /onboarding 리다이렉트
 *   3. 완료 or 온보딩 페이지 → 통과
 * - 사용 위치: Router.tsx의 모든 라우트를 감싸는 최상위 가드
 * 
 * ### 2. AuthGuard (향후 확장용)
 * - 역할: Firebase Auth 인증 여부 확인
 * - 현재 상태: 미구현 (패스스루)
 * - 계획: Firebase Auth 연동 시 구현
 * 
 * ### 3. PremiumGuard (향후 확장용)
 * - 역할: 프리미엄 구독 여부 확인
 * - 현재 상태: 미구현 (패스스루)
 * - 계획: 구독 기능 추가 시 구현
 * 
 * ## 온보딩 완료 체크 로직
 * ```typescript
 * localStorage.getItem('onboarding_completed') === 'true'
 * ```
 * - 저장 위치: localStorage
 * - 키: 'onboarding_completed'
 * - 값: 'true' (문자열)
 * - 설정 위치: 0108mlog-0109/src/components/layout/OnboardingLayout.tsx
 * 
 * ## 관련 파일
 * - 온보딩 레이아웃: 0108mlog-0109/src/components/layout/OnboardingLayout.tsx
 * - 라우터: 0108mlog-0109/src/router/Router.tsx
 * - 인증 서비스: 0108mlog-0109/src/services/auth.ts (ensureAnonymousAuth)
 * 
 * ## 위험요인
 * - ⚠️ localStorage 접근 실패 처리: try-catch로 사생활 보호 모드 대응
 * - ⚠️ localStorage 접근 실패 시 기본값 false → 무한 리다이렉트 가능성
 *   - 현재: /onboarding에서 localStorage 설정 시도
 *   - 개선: sessionStorage 폴백 또는 쿠키 사용 검토
 * - ⚠️ OnboardingGuard가 모든 라우트를 감싸므로, 성능 영향 최소화 필요
 *   - 현재: useLocation() 1회 호출, localStorage 1회 읽기
 *   - 최적화: useMemo 또는 Context 캐싱 검토
 * - ⚠️ /onboarding 경로 하드코딩: 라우트 변경 시 동기화 필요
 */

import { Navigate, useLocation } from 'react-router-dom';
import React from 'react';

/**
 * 온보딩 완료 여부 확인 훅
 * 
 * @returns {boolean} 온보딩 완료 여부
 */
export const useOnboardingStatus = (): boolean => {
  try {
    return localStorage.getItem('onboarding_completed') === 'true';
  } catch {
    // localStorage 접근 실패 시 (예: 사생활 보호 모드) 기본값 반환
    return false;
  }
};

/**
 * 온보딩 가드 컴포넌트
 * 온보딩 미완료 시 온보딩으로 리다이렉트
 * 
 * @component
 * @param {Object} props
 * @param {React.ReactNode} props.children - 보호할 라우트
 * @returns {JSX.Element} 가드된 컴포넌트 또는 리다이렉트
 */
export const OnboardingGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isOnboardingCompleted = useOnboardingStatus();
  
  // 온보딩 페이지가 아니고 온보딩이 완료되지 않았다면 온보딩으로 리다이렉트
  if (!isOnboardingCompleted && location.pathname !== '/onboarding') {
    return <Navigate to="/onboarding" replace />;
  }
  
  return <>{children}</>;
};

/**
 * 인증 가드 컴포넌트 (향후 확장용)
 * 
 * @component
 * @param {Object} props
 * @param {React.ReactNode} props.children - 보호할 라우트
 * @returns {JSX.Element} 가드된 컴포넌트
 */
export const AuthGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // TODO: Firebase Auth 연동 시 구현
  // const user = useAuth();
  // if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

/**
 * 프리미엄 기능 가드 컴포넌트 (향후 확장용)
 * 
 * @component
 * @param {Object} props
 * @param {React.ReactNode} props.children - 보호할 라우트
 * @returns {JSX.Element} 가드된 컴포넌트
 */
export const PremiumGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // TODO: 프리미엄 구독 확인 로직 구현
  // const isPremium = usePremiumStatus();
  // if (!isPremium) return <Navigate to="/profile/subscribe" replace />;
  return <>{children}</>;
};
