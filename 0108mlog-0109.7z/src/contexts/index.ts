/**
 * 마음로그 V5.0 Context 배럴 export
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/contexts/index.ts
 * - 역할: Context Provider 및 Hook 통합 export
 * 
 * ## Export 목록
 * 
 * ### AppContext
 * - AppProvider: 전역 앱 상태 Provider (mode, persona, timeline, emotion)
 * - useAppContext: AppContext 소비 Hook
 * - 위치: 0108mlog-0109/src/contexts/AppContext.tsx
 * 
 * ### UIContext
 * - UIProvider: 전역 UI 상태 Provider (isImmersive, showChatbot, showSafetyLayer)
 * - useUIContext: UIContext 소비 Hook
 * - 위치: 0108mlog-0109/src/contexts/UIContext.tsx
 * 
 * ## 사용 위치
 * - Provider: 0108mlog-0109/src/router/Router.tsx (AppRouter 내부)
 * - Hook 사용:
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx
 *   - 모든 페이지 및 컴포넌트에서 필요 시 import
 * 
 * ## 사용 예시
 * ```typescript
 * import { useAppContext, useUIContext } from '@/contexts';
 * 
 * const { mode, persona, setMode } = useAppContext();
 * const { isImmersive, setIsImmersive } = useUIContext();
 * ```
 */

export { AppProvider, useAppContext } from './AppContext';
export { UIProvider, useUIContext } from './UIContext';
