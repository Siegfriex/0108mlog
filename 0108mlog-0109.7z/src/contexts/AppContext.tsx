/**
 * 마음로그 V5.0 App Context
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/contexts/AppContext.tsx
 * - 역할: 전역 앱 상태 관리 (mode, persona, timeline, emotion)
 * - Provider 위치: 0108mlog-0109/src/router/Router.tsx (AppRouter 내부)
 * 
 * ## 관리하는 상태
 * 
 * ### 1. mode: 'day' | 'night'
 * - 역할: 낮/밤 모드 (테마 + AI 응답 톤 결정)
 * - 초기화: resolveMode() 호출 (시간 기반 자동 결정)
 * - 업데이트:
 *   - 수동: setMode() 호출 (사용자 토글) → override 설정
 *   - 자동: 1분마다 resolveMode() 재실행 (override 없을 때만)
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx (테마, 토글)
 *   - 0108mlog-0109/src/components/chat/DayMode.tsx
 *   - 0108mlog-0109/src/components/chat/NightMode.tsx
 *   - 모든 페이지 컴포넌트 (테마 적용)
 * 
 * ### 2. persona: CoachPersona
 * - 역할: AI 코치 페르소나 설정 (tone, style)
 * - 초기값: DEFAULT_PERSONA (constants.ts)
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx (AIChatbot)
 *   - 0108mlog-0109/src/pages/chat/PersonaSetup.tsx
 *   - 0108mlog-0109/src/pages/profile/PersonaSettings.tsx
 *   - AI API 호출 시 프롬프트에 반영
 * 
 * ### 3. timelineData: TimelineEntry[]
 * - 역할: 대화 타임라인 데이터
 * - 초기값: INITIAL_TIMELINE (mock data)
 * - 액션:
 *   - addTimelineEntry: 새 대화 추가 (배열 앞쪽에 추가)
 *   - deleteTimelineEntry: ID로 대화 삭제
 * - 사용 위치:
 *   - 0108mlog-0109/src/pages/journal/JournalTimeline.tsx
 *   - 0108mlog-0109/src/pages/journal/ConversationDetail.tsx
 *   - 0108mlog-0109/src/components/chat/DayMode.tsx (대화 저장)
 *   - 0108mlog-0109/src/components/chat/NightMode.tsx (대화 저장)
 * 
 * ### 4. currentEmotion: EmotionType | null
 * - 역할: 현재 선택된 감정 (체크인 등)
 * - 초기값: null
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/ui/EmotionSelectModal.tsx
 *   - 체크인 플로우 (checkin 컴포넌트)
 * 
 * ## Mode 해결 로직
 * 
 * ### 초기화 (마운트 시)
 * 1. resolveMode() 호출 (modeResolver.ts)
 * 2. 시간 기반 자동 결정 또는 override 값 반환
 * 3. setModeState() 호출
 * 
 * ### 주기적 업데이트 (1분마다)
 * 1. getModeOverride() 확인
 * 2. override 없으면: resolveMode() 재실행
 * 3. override 있으면: 건너뜀 (사용자 선택 유지)
 * 
 * ### 수동 토글
 * 1. setMode() 호출 (MainLayout 토글 버튼)
 * 2. setModeOverride() 호출 (localStorage 저장)
 * 3. setModeState() 호출 (상태 업데이트)
 * 4. 이후 1분 간격 체크에서 override 감지 → 자동 업데이트 중지
 * 
 * ## 관련 파일
 * - 서비스: 0108mlog-0109/src/services/modeResolver.ts
 * - 타입: 0108mlog-0109/types/index.ts (CoachPersona, TimelineEntry, EmotionType)
 * - 상수: 0108mlog-0109/constants/index.ts (DEFAULT_PERSONA, TIME_CONSTANTS)
 * - Mock 데이터: 0108mlog-0109/src/mock/data.ts (INITIAL_TIMELINE)
 * - Provider: 0108mlog-0109/src/router/Router.tsx
 * - Barrel export: 0108mlog-0109/src/contexts/index.ts
 * 
 * ## 위험요인
 * - ⚠️ setInterval 1분 주기: 메모리 누수 위험
 *   - ✅ cleanup 함수에서 clearInterval() 호출 (완료)
 * - ⚠️ MODE_CHECK_INTERVAL: 1분 (60000ms)
 *   - 너무 짧으면 성능 영향, 너무 길면 자동 전환 지연
 *   - 현재: TIME_CONSTANTS.MODE_CHECK_INTERVAL
 * - ⚠️ useCallback 의존성 배열 빈 배열: 함수 재생성 방지
 *   - 현재: 모든 setter가 빈 의존성 배열 (최적화 완료)
 * - ⚠️ timelineData 초기값: INITIAL_TIMELINE (mock data)
 *   - 실제 Firestore 연동 시 교체 필요
 * - ⚠️ AppContext 값 변경 시: 모든 소비자 리렌더링
 *   - 최적화: 상태별 Context 분리 검토 (현재는 단일 Context)
 */

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { CoachPersona, TimelineEntry, EmotionType } from '../../types';
import { DEFAULT_PERSONA } from '../../constants';
import { INITIAL_TIMELINE } from '../mock/data';
import { resolveMode, setModeOverride, getModeOverride, Mode } from '../services/modeResolver';
import { TIME_CONSTANTS } from '../../constants';

/**
 * AppContext 값 인터페이스
 */
interface AppContextValue {
  // 상태
  mode: Mode;
  persona: CoachPersona;
  timelineData: TimelineEntry[];
  currentEmotion: EmotionType | null;
  
  // 액션
  setMode: (mode: Mode) => void;
  setPersona: (persona: CoachPersona) => void;
  addTimelineEntry: (entry: TimelineEntry) => void;
  deleteTimelineEntry: (id: string) => void;
  setCurrentEmotion: (emotion: EmotionType | null) => void;
}

/**
 * AppContext 생성
 */
const AppContext = createContext<AppContextValue | undefined>(undefined);

/**
 * AppProvider Props
 */
interface AppProviderProps {
  children: ReactNode;
}

/**
 * AppProvider 컴포넌트
 * 
 * 전역 앱 상태를 관리하는 Provider
 */
export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [mode, setModeState] = useState<Mode>('day');
  const [persona, setPersona] = useState<CoachPersona>(DEFAULT_PERSONA);
  const [timelineData, setTimelineData] = useState<TimelineEntry[]>(INITIAL_TIMELINE);
  const [currentEmotion, setCurrentEmotion] = useState<EmotionType | null>(null);

  // 모드 초기화 및 주기적 업데이트
  useEffect(() => {
    const initializeMode = async () => {
      const resolvedMode = await resolveMode();
      setModeState(resolvedMode);
    };

    initializeMode();

    // 수동 override가 없으면 주기적으로 모드 확인 (1분마다)
    const interval = setInterval(async () => {
      const override = getModeOverride();
      if (!override) {
        const resolvedMode = await resolveMode();
        setModeState(resolvedMode);
      }
    }, TIME_CONSTANTS.MODE_CHECK_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  /**
   * 모드 설정 (수동 override 포함)
   */
  const setMode = useCallback((newMode: Mode) => {
    setModeOverride(newMode);
    setModeState(newMode);
  }, []);

  /**
   * 페르소나 설정
   */
  const setPersonaHandler = useCallback((newPersona: CoachPersona) => {
    setPersona(newPersona);
  }, []);

  /**
   * 타임라인 엔트리 추가
   */
  const addTimelineEntry = useCallback((entry: TimelineEntry) => {
    setTimelineData(prev => [entry, ...prev]);
  }, []);

  /**
   * 타임라인 엔트리 삭제
   */
  const deleteTimelineEntry = useCallback((id: string) => {
    setTimelineData(prev => prev.filter(entry => entry.id !== id));
  }, []);

  /**
   * 현재 감정 설정
   */
  const setCurrentEmotionHandler = useCallback((emotion: EmotionType | null) => {
    setCurrentEmotion(emotion);
  }, []);

  const value: AppContextValue = {
    mode,
    persona,
    timelineData,
    currentEmotion,
    setMode,
    setPersona: setPersonaHandler,
    addTimelineEntry,
    deleteTimelineEntry,
    setCurrentEmotion: setCurrentEmotionHandler,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

/**
 * useAppContext Hook
 * 
 * AppContext를 사용하는 Hook
 * Provider 외부에서 사용 시 에러 발생
 */
export const useAppContext = (): AppContextValue => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
