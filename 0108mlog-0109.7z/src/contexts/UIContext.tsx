/**
 * 마음로그 V5.0 UI Context
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/contexts/UIContext.tsx
 * - 역할: 전역 UI 상태 관리 (Immersive 모드, Chatbot, SafetyLayer)
 * - Provider 위치: 0108mlog-0109/src/router/Router.tsx (AppRouter 내부)
 * 
 * ## 관리하는 상태
 * 
 * ### 1. isImmersive: boolean
 * - 역할: Immersive 모드 (GNB/Dock 숨김)
 * - 초기값: false
 * - 활성화 시:
 *   - MainLayout GNB: opacity-20, blur-sm, pointer-events-none
 *   - MainLayout Dock: translate-y-24, opacity-0, pointer-events-none
 *   - Main Stage: px-0 py-0, rounded-none, shadow-none
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx (레이아웃 변경)
 *   - 0108mlog-0109/src/pages/content/ContentImmersion.tsx (몰입 콘텐츠)
 *   - 기타 몰입 모드가 필요한 페이지
 * 
 * ### 2. showChatbot: boolean
 * - 역할: AI Chatbot 오버레이 표시 여부
 * - 초기값: false
 * - 활성화 시:
 *   - AIChatbot 컴포넌트 렌더링 (z-modal)
 *   - 전체 화면 오버레이
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/layout/MainLayout.tsx (GNB 버튼, 오버레이)
 *   - 0108mlog-0109/components/AIChatbot.tsx (레거시)
 * 
 * ### 3. showSafetyLayer: boolean
 * - 역할: 안전망 레이어 표시 여부
 * - 초기값: false
 * - 활성화 시:
 *   - SafetyLayer 컴포넌트 렌더링 (z-safety)
 *   - 위기 감지 시 자동 활성화
 * - 사용 위치:
 *   - 0108mlog-0109/src/components/safety/SafetyLayer.tsx
 *   - 0108mlog-0109/src/services/crisisDetection.ts (위기 감지 시 호출)
 *   - 0108mlog-0109/src/pages/safety/SafetyMain.tsx
 * 
 * ## 상태 설정 함수
 * - setIsImmersive(active: boolean): Immersive 모드 토글
 * - setShowChatbot(show: boolean): Chatbot 표시/숨김
 * - setShowSafetyLayer(show: boolean): SafetyLayer 표시/숨김
 * 
 * ## 관련 파일
 * - Provider: 0108mlog-0109/src/router/Router.tsx
 * - Barrel export: 0108mlog-0109/src/contexts/index.ts
 * - 레이아웃: 0108mlog-0109/src/components/layout/MainLayout.tsx
 * - 컴포넌트:
 *   - 0108mlog-0109/components/AIChatbot.tsx (레거시)
 *   - 0108mlog-0109/src/components/safety/SafetyLayer.tsx
 * 
 * ## 위험요인
 * - ✅ useCallback으로 함수 재생성 방지
 * - ⚠️ UIContext 값 변경 시: 모든 소비자 리렌더링
 *   - 현재: MainLayout에서만 주로 사용 (리렌더링 범위 제한적)
 *   - 최적화: 상태별 Context 분리 검토 (필요 시)
 * - ⚠️ showSafetyLayer: 현재 미사용 (SafetyLayer 컴포넌트 확인 필요)
 *   - 위기 감지 로직과 연동 확인 필요
 */

import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

/**
 * UIContext 값 인터페이스
 */
interface UIContextValue {
  isImmersive: boolean;
  showChatbot: boolean;
  showSafetyLayer: boolean;
  
  setIsImmersive: (active: boolean) => void;
  setShowChatbot: (show: boolean) => void;
  setShowSafetyLayer: (show: boolean) => void;
}

/**
 * UIContext 생성
 */
const UIContext = createContext<UIContextValue | undefined>(undefined);

/**
 * UIProvider Props
 */
interface UIProviderProps {
  children: ReactNode;
}

/**
 * UIProvider 컴포넌트
 * 
 * 전역 UI 상태를 관리하는 Provider
 */
export const UIProvider: React.FC<UIProviderProps> = ({ children }) => {
  const [isImmersive, setIsImmersiveState] = useState(false);
  const [showChatbot, setShowChatbotState] = useState(false);
  const [showSafetyLayer, setShowSafetyLayerState] = useState(false);

  /**
   * 몰입 모드 설정
   */
  const setIsImmersive = useCallback((active: boolean) => {
    setIsImmersiveState(active);
  }, []);

  /**
   * 챗봇 표시 설정
   */
  const setShowChatbot = useCallback((show: boolean) => {
    setShowChatbotState(show);
  }, []);

  /**
   * 안전망 레이어 표시 설정
   */
  const setShowSafetyLayer = useCallback((show: boolean) => {
    setShowSafetyLayerState(show);
  }, []);

  const value: UIContextValue = {
    isImmersive,
    showChatbot,
    showSafetyLayer,
    setIsImmersive,
    setShowChatbot,
    setShowSafetyLayer,
  };

  return (
    <UIContext.Provider value={value}>
      {children}
    </UIContext.Provider>
  );
};

/**
 * useUIContext Hook
 * 
 * UIContext를 사용하는 Hook
 * Provider 외부에서 사용 시 에러 발생
 */
export const useUIContext = (): UIContextValue => {
  const context = useContext(UIContext);
  if (context === undefined) {
    throw new Error('useUIContext must be used within a UIProvider');
  }
  return context;
};
