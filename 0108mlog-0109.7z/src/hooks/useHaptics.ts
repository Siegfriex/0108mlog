import { useCallback } from 'react';

/**
 * 햅틱 피드백 타입
 */
export type HapticType = 'light' | 'medium' | 'heavy' | 'success' | 'warning' | 'error';

/** useHaptics - 햅틱 피드백 | Vibration API, 6종 패턴, 브라우저 호환성 체크 */
export const useHaptics = () => {
  /**
   * 햅틱 피드백 트리거
   */
  const triggerHaptic = useCallback((type: HapticType = 'light') => {
    // Vibration API 지원 확인
    if (!('vibrate' in navigator)) {
      return;
    }

    const patterns: Record<HapticType, number | number[]> = {
      light: 10,
      medium: 20,
      heavy: 30,
      success: [10, 50, 10],
      warning: [20, 50, 20, 50, 20],
      error: [30, 50, 30, 50, 30],
    };

    const pattern = patterns[type];
    // 타입 안정성을 위한 타입 단언
    (navigator as any).vibrate(pattern);
  }, []);

  return {
    triggerHaptic,
  };
};
