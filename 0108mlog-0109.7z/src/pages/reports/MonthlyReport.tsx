/** 월간 리포트 - /reports/monthly | ReportView 레거시 */

import React from 'react';
import { ReportView } from '../../../components/ReportView';
import { useAppContext } from '../../contexts';

/**
 * MonthlyReport 컴포넌트
 */
export const MonthlyReport: React.FC = () => {
  const { timelineData } = useAppContext();

  return <ReportView timelineData={timelineData} />;
};
