/** 콘텐츠 메인 - /content | ContentGallery 레거시, generateHealingContent 호출 */

import React from 'react';
import { ContentGallery } from '../../../components/ContentGallery';
import { useAppContext } from '../../contexts';

/**
 * ContentMain Props 인터페이스
 */
interface ContentMainProps {}

/**
 * ContentMain 컴포넌트
 * 
 * @component
 * @param {ContentMainProps} props - 컴포넌트 props
 * @returns {JSX.Element} ContentMain 컴포넌트
 */
export const ContentMain: React.FC<ContentMainProps> = () => {
  const { persona } = useAppContext();

  return <ContentGallery persona={persona} />;
};
