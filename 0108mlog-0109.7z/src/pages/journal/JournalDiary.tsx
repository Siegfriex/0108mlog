/** 감정 일기 - /journal/diary | 플레이스홀더 페이지 (미구현) */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard, Button } from '../../components/ui';

/**
 * JournalDiary 컴포넌트
 */
export const JournalDiary: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="h-full flex flex-col p-6">
      <div className="flex items-center gap-2 mb-4">
        <button 
          onClick={() => navigate('/journal')} 
          className="p-2 hover:bg-slate-100 rounded-full transition-colors"
        >
          ←
        </button>
        <h2 className="text-xl font-bold text-slate-800">감정 일기</h2>
      </div>
      <GlassCard className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-600 mb-4">감정 일기 기능은 곧 제공될 예정입니다.</p>
          <Button onClick={() => navigate('/journal')} variant="primary">
            돌아가기
          </Button>
        </div>
      </GlassCard>
    </div>
  );
};
