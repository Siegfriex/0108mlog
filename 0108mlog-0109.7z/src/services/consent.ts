/**
 * 마음로그 V5.0 동의 관리 서비스
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/consent.ts
 * - 역할: 대화/일기 원문 저장 동의 상태 관리
 * - 모델: Privacy-first (동의 없어도 감정 수치/태그는 저장 가능)
 * 
 * ## 동의 타입
 * - conversationStorage: 대화/일기 원문 저장 동의
 * - 버전: CONSENT_VERSION = '1.0'
 * 
 * ## 동의 상태 (ConsentState)
 * ```typescript
 * {
 *   conversationStorage: boolean;
 *   consentedAt?: Date; // 동의 시점
 *   revokedAt?: Date; // 철회 시점
 * }
 * ```
 * 
 * ## 제공 함수
 * 
 * ### getConsentState()
 * - 역할: 현재 동의 상태 가져오기
 * - 우선순위:
 *   1. Firestore users/{uid}/consentLogs/conversation_storage
 *   2. localStorage 'consent_conversation_storage'
 *   3. 기본값: { conversationStorage: false }
 * - 동기화: Firestore 데이터를 localStorage에 캐싱
 * 
 * ### saveConsent(consented)
 * - 역할: 동의 저장 (Firestore + localStorage)
 * - 호출: 온보딩, 설정 페이지
 * - Firestore 실패 시: localStorage만 저장 (폴백)
 * 
 * ### canSaveConversation()
 * - 역할: 대화/일기 원문 저장 가능 여부 확인
 * - 호출: firestore.ts saveDiaryEntry()
 * - 반환: boolean
 * 
 * ## Firestore 구조
 * ```
 * users/{userId}/consentLogs/conversation_storage
 * {
 *   userId: string;
 *   consentType: 'conversation_storage';
 *   version: '1.0';
 *   isConsented: boolean;
 *   consentedAt: Timestamp | null;
 *   revokedAt: Timestamp | null;
 *   updatedAt: Timestamp;
 * }
 * ```
 * 
 * ## localStorage 구조
 * - 키: 'consent_conversation_storage'
 * - 값: JSON.stringify({ conversationStorage, consentedAt, revokedAt })
 * 
 * ## Privacy-first 모델
 * - 동의 없어도 저장 가능:
 *   - 감정 수치 (emotion, intensity)
 *   - 컨텍스트 태그 (contextTags)
 *   - 타임스탬프
 * - 동의 필요한 항목:
 *   - 대화 원문 (messages)
 *   - 일기 원문 (content)
 *   - AI 응답 (letters, summaries)
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/services/firestore.ts
 *   - saveDiaryEntry(): canSaveConversation() 확인
 * - 0108mlog-0109/src/pages/profile/Privacy.tsx (설정)
 * - 0108mlog-0109/src/components/layout/OnboardingLayout.tsx (온보딩)
 * 
 * ## 관련 파일
 * - Firebase 설정: 0108mlog-0109/src/config/firebase.ts
 * - 인증: 0108mlog-0109/src/services/auth.ts
 * - Firestore: 0108mlog-0109/src/services/firestore.ts
 * 
 * ## 위험요인
 * - ⚠️ Firestore 저장 실패: localStorage 폴백으로 동기화 불일치 가능
 *   - 개선: 재시도 로직 또는 동기화 확인
 * - ⚠️ localStorage 접근 실패: 사생활 보호 모드에서 에러
 *   - 현재: try-catch로 null 반환
 * - ⚠️ 동의 철회 시: 기존 저장된 데이터 삭제 여부 불명확
 *   - GDPR 준수: 삭제 기능 필요 (deleteAllUserData 활용)
 * - ⚠️ 동의 버전 관리: CONSENT_VERSION 업데이트 시 마이그레이션 필요
 * - ✅ 이중 저장: Firestore + localStorage (가용성 향상)
 * - ✅ Privacy-first: 최소 데이터만 수집
 */

import { collection, doc, setDoc, getDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db } from '../config/firebase';
import { getCurrentUser } from './auth';

const CONSENT_VERSION = '1.0';
const CONSENT_STORAGE_KEY = 'consent_conversation_storage';

/**
 * 동의 상태 인터페이스
 */
export interface ConsentState {
  conversationStorage: boolean;
  consentedAt?: Date;
  revokedAt?: Date;
}

/**
 * 로컬 스토리지에서 동의 상태 가져오기
 */
function getConsentFromLocalStorage(): ConsentState | null {
  try {
    const stored = localStorage.getItem(CONSENT_STORAGE_KEY);
    if (!stored) return null;
    const parsed = JSON.parse(stored);
    return {
      conversationStorage: parsed.conversationStorage ?? false,
      consentedAt: parsed.consentedAt ? new Date(parsed.consentedAt) : undefined,
      revokedAt: parsed.revokedAt ? new Date(parsed.revokedAt) : undefined,
    };
  } catch {
    return null;
  }
}

/**
 * 로컬 스토리지에 동의 상태 저장
 */
function saveConsentToLocalStorage(state: ConsentState): void {
  try {
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify({
      conversationStorage: state.conversationStorage,
      consentedAt: state.consentedAt?.toISOString(),
      revokedAt: state.revokedAt?.toISOString(),
    }));
  } catch (error) {
    console.error('Failed to save consent to localStorage:', error);
  }
}

/**
 * 현재 동의 상태 가져오기
 * 
 * @returns {Promise<ConsentState>} 동의 상태
 */
export async function getConsentState(): Promise<ConsentState> {
  const user = getCurrentUser();
  if (!user) {
    // 사용자가 없으면 로컬 스토리지에서만 확인
    return getConsentFromLocalStorage() || { conversationStorage: false };
  }

  try {
    // Firestore에서 동의 상태 확인
    const consentRef = doc(db, 'users', user.uid, 'consentLogs', 'conversation_storage');
    const consentSnap = await getDoc(consentRef);

    if (consentSnap.exists()) {
      const data = consentSnap.data();
      const state: ConsentState = {
        conversationStorage: data.isConsented ?? false,
        consentedAt: data.consentedAt?.toDate(),
        revokedAt: data.revokedAt?.toDate(),
      };
      
      // 로컬 스토리지 동기화
      saveConsentToLocalStorage(state);
      return state;
    }

    // Firestore에 없으면 로컬 스토리지 확인
    const localState = getConsentFromLocalStorage();
    if (localState) {
      return localState;
    }

    return { conversationStorage: false };
  } catch (error) {
    console.error('Error getting consent state:', error);
    // 에러 시 로컬 스토리지에서 확인
    return getConsentFromLocalStorage() || { conversationStorage: false };
  }
}

/**
 * 동의 저장
 * 
 * @param consented 동의 여부
 * @returns {Promise<void>}
 */
export async function saveConsent(consented: boolean): Promise<void> {
  const user = getCurrentUser();
  if (!user) {
    throw new Error('User must be authenticated to save consent');
  }

  const now = new Date();
  const state: ConsentState = {
    conversationStorage: consented,
    consentedAt: consented ? now : undefined,
    revokedAt: consented ? undefined : now,
  };

  try {
    // Firestore에 저장
    const consentRef = doc(db, 'users', user.uid, 'consentLogs', 'conversation_storage');
    await setDoc(consentRef, {
      userId: user.uid,
      consentType: 'conversation_storage',
      version: CONSENT_VERSION,
      isConsented: consented,
      consentedAt: consented ? serverTimestamp() : null,
      revokedAt: consented ? null : serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    // 로컬 스토리지에도 저장
    saveConsentToLocalStorage(state);
  } catch (error) {
    console.error('Error saving consent:', error);
    // Firestore 저장 실패해도 로컬 스토리지는 저장
    saveConsentToLocalStorage(state);
    throw error;
  }
}

/**
 * 대화/일기 원문 저장 가능 여부 확인
 * 
 * @returns {Promise<boolean>} 저장 가능 여부
 */
export async function canSaveConversation(): Promise<boolean> {
  const state = await getConsentState();
  return state.conversationStorage;
}
