/**
 * 마음로그 V5.0 Firebase Auth 서비스
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/auth.ts
 * - 역할: Firebase Anonymous Auth 부트스트랩 및 인증 상태 관리
 * 
 * ## Anonymous Auth 전략
 * - Firestore 쓰기 전제조건: 인증된 사용자 필요
 * - 앱 시작 시: Router.tsx에서 ensureAnonymousAuth() 호출
 * - 재시도 로직: 네트워크 오류 시 최대 3회 재시도 (지수 백오프)
 * 
 * ## 제공 함수
 * 
 * ### 1. ensureAnonymousAuth()
 * - 역할: 익명 로그인 보장
 * - 호출: Router.tsx useEffect (앱 마운트 시)
 * - 로직:
 *   1. 이미 인증된 사용자 있으면 즉시 반환
 *   2. 없으면 signInAnonymously() 호출
 *   3. 네트워크 오류 시 1초, 2초, 3초 간격으로 재시도
 *   4. 3회 모두 실패 시 에러 throw
 * - 예외 처리: Router.tsx에서 catch하고 앱은 계속 실행
 * 
 * ### 2. onAuthStateChange(callback)
 * - 역할: 인증 상태 변경 리스너
 * - 반환: unsubscribe 함수
 * - 사용 위치: 미사용 (필요 시 컴포넌트에서 호출)
 * 
 * ### 3. getCurrentUser()
 * - 역할: 현재 인증된 사용자 반환
 * - 사용 위치: firestore.ts (모든 데이터 쓰기 작업)
 * 
 * ## 네트워크 오류 처리
 * - 감지 패턴:
 *   - auth/network-request-failed
 *   - auth/internal-error
 *   - Failed to fetch
 *   - ECONNREFUSED
 *   - ERR_CONNECTION_REFUSED
 * - 재시도: 최대 3회, 지수 백오프 (1초, 2초, 3초)
 * - 실패 시: "익명 인증에 실패했습니다. 네트워크 연결을 확인해주세요."
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/router/Router.tsx (useEffect)
 * - 0108mlog-0109/src/services/firestore.ts (getCurrentUserId)
 * - 0108mlog-0109/src/services/consent.ts (getCurrentUser)
 * 
 * ## 관련 파일
 * - Firebase 설정: 0108mlog-0109/src/config/firebase.ts
 * - 에러 로깅: 0108mlog-0109/src/utils/error.ts
 * - 라우터: 0108mlog-0109/src/router/Router.tsx
 * 
 * ## 위험요인
 * - ⚠️ 재시도 로직: 네트워크 오류 시 총 6초 소요 (1+2+3초)
 *   - 앱 초기 로딩 시간에 영향
 * - ⚠️ 재시도 실패 시: 앱은 계속 실행, Firestore 쓰기만 실패
 *   - 오프라인 모드로 동작 (localStorage만 사용)
 * - ⚠️ auth.currentUser: 동기적 접근, 초기화 전 null 가능
 *   - ensureAnonymousAuth()로 보장
 * - ✅ logError로 모든 에러 로깅
 * - ✅ 지수 백오프로 네트워크 부하 최소화
 */

import { signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { auth } from '../config/firebase';
import { logError } from '../utils/error';

/**
 * Anonymous Auth 자동 부트스트랩
 * 
 * 앱 시작 시 자동으로 익명 인증을 수행하여 Firestore 쓰기 전제 조건을 충족합니다.
 * 이미 인증된 사용자가 있으면 재인증하지 않습니다.
 * 
 * @returns {Promise<User>} 인증된 사용자 객체
 * @throws {Error} 인증 실패 시
 */
export async function ensureAnonymousAuth(): Promise<User> {
  // 이미 인증된 사용자가 있으면 반환
  if (auth.currentUser) {
    return auth.currentUser;
  }

  try {
    // 익명 인증 수행
    const userCredential = await signInAnonymously(auth);
    return userCredential.user;
  } catch (error: unknown) {
    logError('ensureAnonymousAuth', error);
    
    // 네트워크 오류 등 재시도 가능한 오류 처리
    const errorCode = (error && typeof error === 'object' && 'code' in error) 
      ? String(error.code) 
      : '';
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    if (errorCode === 'auth/network-request-failed' || 
        errorCode === 'auth/internal-error' ||
        errorMessage.includes('Failed to fetch') ||
        errorMessage.includes('ECONNREFUSED') ||
        errorMessage.includes('ERR_CONNECTION_REFUSED')) {
      // 재시도 로직 (최대 3회)
      for (let i = 0; i < 3; i++) {
        await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1))); // 지수 백오프
        try {
          const userCredential = await signInAnonymously(auth);
          return userCredential.user;
        } catch (retryError) {
          if (i === 2) {
            throw new Error('익명 인증에 실패했습니다. 네트워크 연결을 확인해주세요.');
          }
        }
      }
    }
    
    throw new Error('익명 인증에 실패했습니다.');
  }
}

/**
 * 인증 상태 변경 리스너
 * 
 * @param callback 인증 상태 변경 시 호출될 콜백 함수
 * @returns {() => void} 리스너 해제 함수
 */
export function onAuthStateChange(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

/**
 * 현재 인증된 사용자 가져오기
 * 
 * @returns {User | null} 현재 인증된 사용자 또는 null
 */
export function getCurrentUser(): User | null {
  return auth.currentUser;
}
