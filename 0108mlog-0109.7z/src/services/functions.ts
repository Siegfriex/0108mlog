/**
 * 마음로그 V5.0 Firebase Functions 클라이언트 서비스
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/functions.ts
 * - 역할: Firebase Callable Functions 호출 헬퍼
 * - 리전: asia-northeast3 (서울)
 * 
 * ## Functions 목록 (7개)
 * 1. generateDayModeResponse: Day Mode 채팅 응답 생성
 * 2. generateNightModeLetter: Night Mode 편지 생성
 * 3. generateMonthlyNarrative: 월간 회고록 생성
 * 4. generateHealingContent: 큐레이션 콘텐츠 생성
 * 5. generateChatbotResponse: AI Chatbot 응답 생성
 * 6. generateMicroAction: 마이크로 액션 생성
 * 7. generateTimelineAnalysis: 타임라인 분석
 * 
 * ## 호출 경로
 * ```
 * 컴포넌트
 *   → gemini.ts (generateXXX)
 *     → apiPolicy.ts (callWithPolicy)
 *       → functions.ts (callFunction)
 *         → Firebase Functions (asia-northeast3)
 *           → functions/src/api/gemini.ts
 * ```
 * 
 * ## 에러 처리
 * - 권한 거부: 'functions/permission-denied'
 * - 잘못된 요청: 'functions/invalid-argument'
 * - 타임아웃: 'functions/deadline-exceeded'
 * - 기타 에러: 원본 에러 재throw
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/services/ai/gemini.ts (모든 AI API 함수)
 * 
 * ## 관련 파일
 * - Firebase Functions: 0108mlog-0109/functions/src/api/gemini.ts
 * - API 정책: 0108mlog-0109/src/services/apiPolicy.ts
 * - Firebase 설정: 0108mlog-0109/src/config/firebase.ts
 * - 에러 로깅: 0108mlog-0109/src/utils/error.ts
 * 
 * ## 위험요인
 * - ⚠️ Firebase Functions 타임아웃: Cloud Functions 기본 60초
 *   - callWithPolicy에서 8-10초 타임아웃 설정 (재시도 포함)
 * - ⚠️ 에러 코드 파싱: error.code 접근 시 타입 안정성
 *   - 현재: typeof 체크로 안전하게 처리
 * - ✅ logError로 모든 에러 로깅
 * - ⚠️ TResponse 타입: 응답 구조 { success, data, error, fallback } 가정
 *   - gemini.ts에서 이 구조로 응답 처리
 */

import { getFunctions, httpsCallable, Functions } from 'firebase/functions';
import app from '../config/firebase';
import { logError } from '../utils/error';

/**
 * Firebase Functions 인스턴스
 * 리전: asia-northeast3 (서울)
 */
const functionsInstance: Functions = getFunctions(app, 'asia-northeast3');

/**
 * Firebase Callable Function 호출 헬퍼
 * 
 * @template TRequest 요청 데이터 타입
 * @template TResponse 응답 데이터 타입
 * @param functionName 호출할 함수 이름
 * @param data 요청 데이터
 * @returns {Promise<TResponse>} 함수 응답 데이터
 * @throws {Error} 함수 호출 실패 시
 */
export async function callFunction<TRequest, TResponse>(
  functionName: string,
  data: TRequest
): Promise<TResponse> {

  try {
    // Callable Functions는 result.data에 직접 응답을 반환
    // Functions에서 { success: true, data: ... } 형태로 반환하므로
    // result.data가 이미 { success, data, error, fallback } 구조임
    const callable = httpsCallable<TRequest, TResponse>(functionsInstance, functionName);
    const result = await callable(data);
    return result.data as TResponse;
  } catch (error: unknown) {
    logError(`callFunction:${functionName}`, error);
    
    // Firebase Functions 에러 처리
    const errorCode = (error && typeof error === 'object' && 'code' in error) 
      ? String(error.code) 
      : '';
    
    if (errorCode === 'functions/permission-denied') {
      throw new Error('권한이 없습니다.');
    } else if (errorCode === 'functions/invalid-argument') {
      throw new Error('잘못된 요청입니다.');
    } else if (errorCode === 'functions/deadline-exceeded') {
      throw new Error('요청 시간이 초과되었습니다.');
    }
    
    throw error instanceof Error ? error : new Error(String(error));
  }
}
