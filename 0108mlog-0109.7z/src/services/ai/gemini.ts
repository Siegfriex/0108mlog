/**
 * 마음로그 V5.0 Gemini API 서비스 래퍼
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/ai/gemini.ts
 * - 역할: Gemini API 호출 래퍼 (Firebase Functions 경유)
 * - 패턴: Service Layer → Functions → Cloud Functions → Gemini API
 * 
 * ## 제공 함수 (7개)
 * 
 * ### 1. generateDayModeResponse
 * - 역할: Day Mode 채팅 응답 생성
 * - 호출: DayMode 컴포넌트
 * - 타임아웃: 8초, 재시도: 3회
 * - 폴백: "분석에 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요."
 * 
 * ### 2. generateNightModeLetter
 * - 역할: Night Mode 편지 생성
 * - 호출: NightMode 컴포넌트
 * - 타임아웃: 8초, 재시도: 3회
 * - 폴백: "편지를 작성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요."
 * 
 * ### 3. generateMonthlyNarrative
 * - 역할: 월간 회고록 생성
 * - 호출: MonthlyReport 컴포넌트
 * - 타임아웃: 10초, 재시도: 2회
 * - 폴백: "리포트를 생성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요."
 * 
 * ### 4. generateHealingContent
 * - 역할: 큐레이션 콘텐츠 생성
 * - 호출: ContentGallery 컴포넌트
 * - 타임아웃: 8초, 재시도: 2회
 * - 폴백: null
 * 
 * ### 5. generateChatbotResponse
 * - 역할: AI Chatbot 응답 생성
 * - 호출: AIChatbot 컴포넌트
 * - 타임아웃: 8초, 재시도: 3회
 * - 폴백: "응답을 생성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요."
 * 
 * ### 6. generateMicroAction
 * - 역할: 마이크로 액션 생성
 * - 호출: ActionFeedback 컴포넌트
 * - 타임아웃: 8초, 재시도: 3회
 * - 폴백: { id: 'fallback', title: '심호흡 하기', ... }
 * 
 * ### 7. generateTimelineAnalysis
 * - 역할: 타임라인 분석 (사용 위치 확인 필요)
 * - 타임아웃: 10초, 재시도: 2회
 * - 폴백: "분석 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요."
 * 
 * ## 호출 흐름
 * ```
 * 컴포넌트 (예: DayMode)
 *   → generateDayModeResponse()
 *     → callWithPolicy() (apiPolicy.ts)
 *       → callFunction() (functions.ts)
 *         → httpsCallable() (Firebase SDK)
 *           → generateDayModeResponse (Cloud Functions)
 *             → Gemini API
 * ```
 * 
 * ## 응답 구조
 * ```typescript
 * {
 *   success: boolean;
 *   data?: T; // 실제 응답 데이터
 *   error?: string; // 에러 메시지
 *   fallback?: T; // 폴백 데이터 (타임아웃/에러 시)
 * }
 * ```
 * 
 * ## 폴백 전략
 * - 성공 시: response.data 반환
 * - 실패 시: response.fallback 또는 response.error 반환
 * - 네트워크 오류 시: 재시도 후 폴백
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/components/chat/DayMode.tsx
 * - 0108mlog-0109/src/components/chat/NightMode.tsx
 * - 0108mlog-0109/src/pages/reports/MonthlyReport.tsx
 * - 0108mlog-0109/components/ContentGallery.tsx (레거시)
 * - 0108mlog-0109/components/AIChatbot.tsx (레거시)
 * - 0108mlog-0109/src/components/actions/* (마이크로 액션)
 * 
 * ## 관련 파일
 * - Functions: 0108mlog-0109/src/services/functions.ts
 * - API 정책: 0108mlog-0109/src/services/apiPolicy.ts
 * - Cloud Functions: 0108mlog-0109/functions/src/api/gemini.ts
 * - 타입: 0108mlog-0109/types/index.ts
 * 
 * ## 위험요인
 * - ⚠️ callWithPolicy: 재시도 로직으로 총 소요 시간 증가
 *   - 예: 3회 재시도 시 최대 24초 소요 가능 (8초 × 3)
 * - ⚠️ 폴백 메시지: 사용자 경험에 영향
 *   - 현재: 한국어 메시지 하드코딩 (다국어 지원 시 변경 필요)
 * - ⚠️ response 구조 의존성: { success, data, error, fallback }
 *   - Cloud Functions 응답 구조 변경 시 동기화 필요
 * - ✅ callWithPolicy로 타임아웃, 재시도, 폴백 일관성 보장
 */

import { callFunction } from '../functions';
import { callWithPolicy } from '../apiPolicy';
import { CoachPersona, ContentData, MicroAction, EmotionType, TimelineEntry } from '../../../types';

// 타입 정의
interface DayModeResponse {
  success: boolean;
  data?: string;
  error?: string;
  fallback?: string;
}

interface NightModeResponse {
  success: boolean;
  data?: string;
  error?: string;
  fallback?: string;
}

interface HealingContentResponse {
  success: boolean;
  data?: ContentData;
  error?: string;
  fallback?: null;
}

interface MicroActionResponse {
  success: boolean;
  data?: MicroAction;
  error?: string;
  fallback?: MicroAction;
}

/**
 * Day Mode 채팅 응답 생성
 */
export const generateDayModeResponse = async (
  userMessage: string,
  history: string[],
  persona: CoachPersona
): Promise<string> => {
  const response = await callWithPolicy<DayModeResponse>(
    () => callFunction<{
      userMessage: string;
      history: string[];
      persona: CoachPersona;
    }, DayModeResponse>('generateDayModeResponse', {
      userMessage,
      history,
      persona,
    }),
    {
      timeout: 8000,
      maxRetries: 3,
      fallback: () => ({
        success: false,
        fallback: '분석에 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요.',
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || '응답을 생성할 수 없습니다.';
  }

  return response.fallback?.fallback || response.error || '잠시 연결이 불안정합니다.';
};

/**
 * Night Mode 편지 생성
 */
export const generateNightModeLetter = async (
  diaryEntry: string,
  persona: CoachPersona
): Promise<string> => {
  const response = await callWithPolicy<NightModeResponse>(
    () => callFunction<{
      diaryEntry: string;
      persona: CoachPersona;
    }, NightModeResponse>('generateNightModeLetter', {
      diaryEntry,
      persona,
    }),
    {
      timeout: 8000,
      maxRetries: 3,
      fallback: () => ({
        success: false,
        fallback: '편지를 작성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요.',
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || '편지를 작성하는 중 오류가 발생했습니다.';
  }

  return response.fallback?.fallback || response.error || '지금은 편지를 쓸 수 없는 상태예요.';
};

/**
 * 월간 회고록 생성
 */
export const generateMonthlyNarrative = async (summary?: string): Promise<string> => {
  const response = await callWithPolicy<DayModeResponse>(
    () => callFunction<{ summary?: string }, DayModeResponse>(
      'generateMonthlyNarrative',
      { summary }
    ),
    {
      timeout: 10000,
      maxRetries: 2,
      fallback: () => ({
        success: false,
        fallback: '리포트를 생성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요.',
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || '리포트를 생성할 수 없습니다.';
  }

  return response.fallback?.fallback || response.error || '리포트를 불러오는 중 오류가 발생했습니다.';
};

/**
 * 큐레이션 콘텐츠 생성
 */
export const generateHealingContent = async (
  emotionState: string,
  persona: CoachPersona
): Promise<ContentData | null> => {
  const response = await callWithPolicy<HealingContentResponse>(
    () => callFunction<{
      emotionState: string;
      persona: CoachPersona;
    }, HealingContentResponse>('generateHealingContent', {
      emotionState,
      persona,
    }),
    {
      timeout: 8000,
      maxRetries: 2,
      fallback: () => ({
        success: false,
        fallback: null,
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || null;
  }

  return null;
};

/**
 * AI 챗봇 응답 생성
 */
export const generateChatbotResponse = async (
  userMessage: string,
  history: { role: string; content: string }[],
  persona: CoachPersona
): Promise<string> => {
  const response = await callWithPolicy<DayModeResponse>(
    () => callFunction<{
      userMessage: string;
      history: { role: string; content: string }[];
      persona: CoachPersona;
    }, DayModeResponse>('generateChatbotResponse', {
      userMessage,
      history,
      persona,
    }),
    {
      timeout: 8000,
      maxRetries: 3,
      fallback: () => ({
        success: false,
        fallback: '응답을 생성하는 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요.',
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || '응답을 생성할 수 없습니다.';
  }

  return response.fallback?.fallback || response.error || '연결에 문제가 발생했습니다.';
};

/**
 * 마이크로 액션 생성
 */
export const generateMicroAction = async (
  emotion: EmotionType,
  intensity: number,
  userContext: string
): Promise<MicroAction | null> => {
  const fallbackAction: MicroAction = {
    id: 'fallback',
    title: '심호흡 하기',
    description: '편안한 자세로 눈을 감고 3번 깊게 숨을 들이마시고 내쉬세요.',
    duration: '1 min',
    type: 'breathing',
  };

  const response = await callWithPolicy<MicroActionResponse>(
    () => callFunction<{
      emotion: EmotionType;
      intensity: number;
      userContext: string;
    }, MicroActionResponse>('generateMicroAction', {
      emotion,
      intensity,
      userContext,
    }),
    {
      timeout: 8000,
      maxRetries: 3,
      fallback: () => ({
        success: false,
        fallback: fallbackAction,
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || fallbackAction;
  }

  return response.fallback?.fallback || fallbackAction;
};

/**
 * 타임라인 분석
 */
export const generateTimelineAnalysis = async (entries: TimelineEntry[]): Promise<string> => {
  const response = await callWithPolicy<DayModeResponse>(
    () => callFunction<{ entries: TimelineEntry[] }, DayModeResponse>(
      'generateTimelineAnalysis',
      { entries }
    ),
    {
      timeout: 10000,
      maxRetries: 2,
      fallback: () => ({
        success: false,
        fallback: '분석 중 시간이 걸리고 있어요. 잠시 후 다시 시도해주세요.',
      }),
    }
  );

  if (response.success && response.data) {
    return response.data.data || response.data.fallback || 'Analysis unavailable.';
  }

  return response.fallback?.fallback || response.error || '분석 중 오류가 발생했습니다.';
};
