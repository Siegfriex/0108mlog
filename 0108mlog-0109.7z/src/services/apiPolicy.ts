/**
 * 마음로그 V5.0 API 정책 중앙화 서비스
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/apiPolicy.ts
 * - 역할: 네트워크 오류 감지, 타임아웃, 재시도, 백오프, 폴백 메커니즘 통합 관리
 * 
 * ## 제공 함수
 * 
 * ### callWithPolicy<T>(apiCall, options)
 * - 역할: API 호출 래퍼 (재시도/백오프/타임아웃/폴백 포함)
 * - 사용 위치: gemini.ts의 모든 AI API 함수
 * 
 * ## 정책 옵션 (ApiPolicyOptions)
 * - timeout: 타임아웃 시간 (ms), 기본값: TIME_CONSTANTS.API_TIMEOUT
 * - maxRetries: 최대 재시도 횟수, 기본값: TIME_CONSTANTS.MAX_RETRIES
 * - retryDelay: 초기 재시도 지연 시간 (ms), 기본값: 1000
 * - backoffMultiplier: 백오프 배수, 기본값: 2
 * - fallback: 폴백 함수
 * 
 * ## 재시도 로직
 * 1. API 호출 시도
 * 2. 성공 시: { success: true, data: result } 반환
 * 3. 실패 시:
 *    - 네트워크 오류 아니면: 즉시 실패 (폴백 사용)
 *    - 네트워크 오류면: 재시도
 *    - 지수 백오프 지연 (1초, 2초, 4초, ...)
 * 4. 모든 재시도 실패 시: 폴백 사용 또는 에러 반환
 * 
 * ## 네트워크 오류 감지
 * - 패턴:
 *   - Failed to fetch
 *   - ECONNREFUSED, ERR_CONNECTION_REFUSED
 *   - ERR_NETWORK, ERR_INTERNET_DISCONNECTED
 *   - ERR_TIMED_OUT, ETIMEDOUT
 *   - ENOTFOUND, ECONNRESET
 *   - network, timeout, NetworkError
 * - Firebase Functions 오류:
 *   - functions/deadline-exceeded
 *   - functions/unavailable
 *   - functions/internal
 * 
 * ## 타임아웃 처리
 * - Promise.race() 사용
 * - 타임아웃 Promise vs API 호출 Promise 경쟁
 * - 타임아웃 시: "Request timeout" 에러
 * 
 * ## 지수 백오프
 * - 계산식: baseDelay * (multiplier ^ attempt)
 * - 예: 1초, 2초, 4초, 8초, ...
 * - 네트워크 부하 완화
 * 
 * ## 폴백 메커니즘
 * - 폴백 함수 제공 시:
 *   - 비네트워크 오류: 즉시 폴백 사용
 *   - 모든 재시도 실패: 폴백 사용
 * - 폴백 결과: { success: false, error, fallback, _isMockData: true }
 * - _isMockData 플래그: Mock 데이터 표시
 * 
 * ## 응답 구조 (ApiResponse<T>)
 * ```typescript
 * {
 *   success: boolean;
 *   data?: T; // 성공 시
 *   error?: string; // 실패 시
 *   fallback?: T; // 폴백 데이터
 *   _isMockData?: boolean; // Mock 데이터 플래그
 * }
 * ```
 * 
 * ## 사용 예시
 * ```typescript
 * const response = await callWithPolicy<DayModeResponse>(
 *   () => callFunction('generateDayModeResponse', { ... }),
 *   {
 *     timeout: 8000,
 *     maxRetries: 3,
 *     fallback: () => ({ fallback: '응답 생성 중...' })
 *   }
 * );
 * ```
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/services/ai/gemini.ts (모든 AI API 함수)
 * 
 * ## 관련 파일
 * - 상수: 0108mlog-0109/constants/index.ts (TIME_CONSTANTS)
 * - Functions: 0108mlog-0109/src/services/functions.ts
 * - Gemini: 0108mlog-0109/src/services/ai/gemini.ts
 * 
 * ## 위험요인
 * - ⚠️ maxRetries 설정: 너무 많으면 총 소요 시간 증가
 *   - 예: 3회 재시도, 8초 타임아웃 → 최대 32초 소요
 * - ⚠️ 네트워크 오류 패턴: 신규 패턴 추가 필요 시 업데이트
 *   - 현재: 주요 패턴 포함
 * - ⚠️ Promise.race(): 타임아웃 후에도 API 호출은 계속됨
 *   - Firebase Functions에서 취소 불가
 * - ⚠️ 폴백 함수 실패: 에러 catch하고 { success: false, error } 반환
 * - ✅ _isMockData 플래그: 폴백 데이터 명시
 * - ✅ 지수 백오프: 네트워크 부하 완화
 * - ✅ isNetworkError(): 포괄적 네트워크 오류 감지
 */

import { TIME_CONSTANTS } from '../../constants';

export interface ApiPolicyOptions {
  timeout?: number; // 타임아웃 시간 (ms), 기본값: TIME_CONSTANTS.API_TIMEOUT
  maxRetries?: number; // 최대 재시도 횟수, 기본값: TIME_CONSTANTS.MAX_RETRIES
  retryDelay?: number; // 초기 재시도 지연 시간 (ms), 기본값: 1000
  backoffMultiplier?: number; // 백오프 배수, 기본값: 2
  fallback?: () => unknown; // 폴백 함수
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  fallback?: T;
  _isMockData?: boolean; // Mock 데이터 플래그
}

/**
 * 네트워크 오류 패턴 감지
 */
function isNetworkError(error: unknown): boolean {
  if (!error) return false;

  const errorMessage = error instanceof Error ? error.message : String(error);
  const errorCode = (error && typeof error === 'object' && 'code' in error) 
    ? String(error.code) 
    : '';

  // 네트워크 오류 패턴
  const networkErrorPatterns = [
    'Failed to fetch',
    'ECONNREFUSED',
    'ERR_CONNECTION_REFUSED',
    'ERR_NETWORK',
    'ERR_INTERNET_DISCONNECTED',
    'ERR_TIMED_OUT',
    'ETIMEDOUT',
    'ENOTFOUND',
    'ECONNRESET',
    'network',
    'timeout',
    'NetworkError',
  ];

  // Firebase Functions 오류 코드
  const firebaseErrorCodes = [
    'functions/deadline-exceeded',
    'functions/unavailable',
    'functions/internal',
  ];

  const lowerMessage = errorMessage.toLowerCase();
  const lowerCode = errorCode.toLowerCase();

  return (
    networkErrorPatterns.some(pattern => 
      lowerMessage.includes(pattern.toLowerCase()) || 
      lowerCode.includes(pattern.toLowerCase())
    ) ||
    firebaseErrorCodes.some(code => lowerCode === code)
  );
}

/**
 * 지수 백오프 계산
 */
function calculateBackoffDelay(
  attempt: number,
  baseDelay: number,
  multiplier: number
): number {
  return baseDelay * Math.pow(multiplier, attempt);
}

/**
 * API 호출 래퍼 (재시도/백오프/타임아웃/폴백 포함)
 * 
 * @template T 응답 타입
 * @param apiCall API 호출 함수
 * @param options 정책 옵션
 * @returns {Promise<ApiResponse<T>>} API 응답
 */
export async function callWithPolicy<T>(
  apiCall: () => Promise<T>,
  options: ApiPolicyOptions = {}
): Promise<ApiResponse<T>> {
  const {
    timeout = TIME_CONSTANTS.API_TIMEOUT,
    maxRetries = TIME_CONSTANTS.MAX_RETRIES,
    retryDelay = 1000,
    backoffMultiplier = 2,
    fallback,
  } = options;

  let lastError: unknown = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      // 타임아웃과 API 호출을 경쟁
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => {
          reject(new Error('Request timeout'));
        }, timeout);
      });

      const result = await Promise.race([apiCall(), timeoutPromise]);

      // 성공 시 응답 반환
      return {
        success: true,
        data: result,
      };
    } catch (error: unknown) {
      lastError = error;

      // 네트워크 오류가 아니면 즉시 실패
      if (!isNetworkError(error)) {
        const errorMessage = error instanceof Error ? error.message : 'API call failed';
        
        // 폴백이 있으면 사용
        if (fallback) {
          try {
            const fallbackResult = await Promise.resolve(fallback());
            return {
              success: false,
              error: errorMessage,
              fallback: fallbackResult as T,
              _isMockData: true,
            };
          } catch (fallbackError) {
            return {
              success: false,
              error: errorMessage,
            };
          }
        }

        return {
          success: false,
          error: errorMessage,
        };
      }

      // 마지막 시도면 중단
      if (attempt === maxRetries) {
        break;
      }

      // 백오프 지연
      const delay = calculateBackoffDelay(attempt, retryDelay, backoffMultiplier);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  // 모든 재시도 실패 시 폴백 사용
  const finalErrorMessage = lastError instanceof Error 
    ? lastError.message 
    : 'All retries failed';
    
  if (fallback) {
    try {
      const fallbackResult = await Promise.resolve(fallback());
      return {
        success: false,
        error: finalErrorMessage,
        fallback: fallbackResult as T,
        _isMockData: true,
      };
    } catch (fallbackError) {
      return {
        success: false,
        error: finalErrorMessage,
      };
    }
  }

  return {
    success: false,
    error: finalErrorMessage,
  };
}
