/**
 * 마음로그 V5.0 Day/Night Mode Resolver
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/services/modeResolver.ts
 * - 역할: 시간대, 사용자 설정, 수동 override 기반 모드 결정
 * 
 * ## Mode 타입
 * - 'day': 낮 모드 (채팅, 밝은 테마)
 * - 'night': 밤 모드 (일기, 어두운 테마)
 * 
 * ## 모드 결정 우선순위
 * 1. 수동 override (localStorage 'mode_override')
 * 2. 자동 모드 설정 (autoDayNightMode가 true인 경우)
 * 3. 기본값: 'day'
 * 
 * ## 자동 모드 로직 (resolveAutoMode)
 * - Day Mode: dayModeStartTime ~ nightModeStartTime
 *   - 기본값: 06:00 ~ 18:00
 * - Night Mode: nightModeStartTime ~ dayModeStartTime
 *   - 기본값: 18:00 ~ 06:00 (자정 넘김)
 * - 자정 넘김 처리: startMinutes > endMinutes 경우 특별 처리
 * 
 * ## 제공 함수
 * 
 * ### resolveMode()
 * - 역할: 현재 모드 결정
 * - 호출: AppContext useEffect (1분마다)
 * - 로직:
 *   1. localStorage 'mode_override' 확인
 *   2. 없으면 getUserSettings() 호출
 *   3. autoDayNightMode 확인 (기본값: true)
 *   4. 자동 모드면 resolveAutoMode() 호출
 *   5. 수동 모드면 'day' 반환
 * 
 * ### setModeOverride(mode)
 * - 역할: 수동 모드 override 설정
 * - 호출: AppContext setMode(), MainLayout 토글
 * - 저장: localStorage 'mode_override'
 * 
 * ### getModeOverride()
 * - 역할: 현재 override 모드 가져오기
 * - 호출: AppContext useEffect (주기적 체크)
 * - 반환: 'day' | 'night' | null
 * 
 * ## 시간 처리
 * - getCurrentTimeString(): 현재 시간 "HH:mm" 형식
 * - timeToMinutes(): "HH:mm" → 분 단위 변환
 * - isTimeInRange(): 시간 범위 확인 (자정 넘김 지원)
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/contexts/AppContext.tsx
 *   - 초기화 시 resolveMode() 호출
 *   - 1분마다 getModeOverride() 확인 후 resolveMode() 재실행
 *   - setMode()에서 setModeOverride() 호출
 * - 0108mlog-0109/src/components/layout/MainLayout.tsx
 *   - 토글 버튼에서 setMode() 호출
 * 
 * ## 관련 파일
 * - Context: 0108mlog-0109/src/contexts/AppContext.tsx
 * - Firestore: 0108mlog-0109/src/services/firestore.ts (getUserSettings)
 * - 레이아웃: 0108mlog-0109/src/components/layout/MainLayout.tsx
 * 
 * ## 위험요인
 * - ⚠️ localStorage 접근 실패: 사생활 보호 모드에서 에러
 *   - 현재: try-catch 없음 (AppContext에서 처리)
 * - ⚠️ getUserSettings() 비동기: 초기 로딩 시간 영향
 *   - 현재: catch로 기본값 'day' 반환
 * - ⚠️ 자정 넘김 로직: 복잡도 증가
 *   - 테스트 필요: 22:00 ~ 06:00 범위 확인
 * - ⚠️ 1분 주기 체크: AppContext에서 setInterval 사용
 *   - override 있으면 건너뜀 (수동 선택 유지)
 * - ✅ 기본값 'day': 에러 시 안전한 기본값
 * - ✅ 자동 모드 기본 활성화: 사용자 편의
 */

import { getUserSettings } from './firestore';

export type Mode = 'day' | 'night';

interface ModeSettings {
  autoDayNightMode: boolean;
  dayModeStartTime?: string; // HH:mm 형식
  nightModeStartTime?: string; // HH:mm 형식
}

/**
 * 현재 시간을 HH:mm 형식으로 반환
 */
function getCurrentTimeString(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * 시간 문자열(HH:mm)을 분 단위로 변환
 */
function timeToMinutes(time: string): number {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

/**
 * 현재 시간이 지정된 시간 범위 내에 있는지 확인
 * 
 * @param startTime 시작 시간 (HH:mm)
 * @param endTime 종료 시간 (HH:mm)
 * @returns 범위 내에 있으면 true
 */
function isTimeInRange(startTime: string, endTime: string): boolean {
  const currentMinutes = timeToMinutes(getCurrentTimeString());
  const startMinutes = timeToMinutes(startTime);
  const endMinutes = timeToMinutes(endTime);

  // 자정을 넘어가는 경우 처리 (예: 22:00 ~ 06:00)
  if (startMinutes > endMinutes) {
    return currentMinutes >= startMinutes || currentMinutes < endMinutes;
  }

  return currentMinutes >= startMinutes && currentMinutes < endMinutes;
}

/**
 * 자동 모드 기반으로 현재 모드 결정
 * 
 * @param settings 사용자 설정
 * @returns 'day' 또는 'night'
 */
function resolveAutoMode(settings: ModeSettings): Mode {
  const dayStart = settings.dayModeStartTime || '06:00';
  const nightStart = settings.nightModeStartTime || '18:00';

  // Day Mode 시간대: dayStart ~ nightStart
  if (isTimeInRange(dayStart, nightStart)) {
    return 'day';
  }

  // Night Mode 시간대: nightStart ~ dayStart
  return 'night';
}

/**
 * 현재 모드 결정
 * 
 * 우선순위:
 * 1. 로컬 스토리지의 수동 override (있는 경우)
 * 2. 자동 모드 설정 (autoDayNightMode가 true인 경우)
 * 3. 기본값: 'day'
 * 
 * @returns {Promise<Mode>} 현재 모드
 */
export async function resolveMode(): Promise<Mode> {
  // 1. 수동 override 확인
  const manualOverride = localStorage.getItem('mode_override') as Mode | null;
  if (manualOverride === 'day' || manualOverride === 'night') {
    return manualOverride;
  }

  try {
    // 2. 사용자 설정 확인
    const settings = await getUserSettings();
    
    if (settings?.autoDayNightMode !== false) {
      // 자동 모드 활성화 (기본값도 true)
      return resolveAutoMode({
        autoDayNightMode: settings?.autoDayNightMode ?? true,
        dayModeStartTime: settings?.dayModeStartTime,
        nightModeStartTime: settings?.nightModeStartTime,
      });
    }

    // 자동 모드 비활성화 시 기본값 반환
    return 'day';
  } catch (error) {
    console.error('Error resolving mode:', error);
    // 에러 시 기본값 반환
    return 'day';
  }
}

/**
 * 수동 모드 override 설정
 * 
 * @param mode 설정할 모드
 */
export function setModeOverride(mode: Mode | null): void {
  if (mode === null) {
    localStorage.removeItem('mode_override');
  } else {
    localStorage.setItem('mode_override', mode);
  }
}

/**
 * 현재 수동 override 모드 가져오기
 * 
 * @returns 현재 override 모드 또는 null
 */
export function getModeOverride(): Mode | null {
  const override = localStorage.getItem('mode_override');
  if (override === 'day' || override === 'night') {
    return override;
  }
  return null;
}
