/**
 * 마음로그 V5.0 온보딩 레이아웃 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/layout/OnboardingLayout.tsx
 * - 역할: 온보딩 전용 레이아웃 (GNB/Dock 없음)
 * - 사용 위치: 0108mlog-0109/src/router/Router.tsx (/onboarding 라우트)
 * 
 * ## 온보딩 플로우 구조
 * ```
 * OnboardingLayout
 *   ├─ Background (Gradient)
 *   ├─ NoiseOverlay (텍스처)
 *   └─ OnboardingFlow (9개 스텝)
 *       ├─ Step 1: 웰컴
 *       ├─ Step 2: 앱 소개
 *       ├─ Step 3: 페르소나 선택
 *       ├─ Step 4: 낮밤 모드 설정
 *       ├─ Step 5: 알림 설정
 *       ├─ Step 6: 개인정보 동의
 *       ├─ Step 7: 데이터 수집 동의
 *       ├─ Step 8: 최종 확인
 *       └─ Step 9: 완료
 * ```
 * 
 * ## 온보딩 완료 로직
 * 1. OnboardingFlow에서 onComplete 콜백 호출
 * 2. handleOnboardingComplete() 실행
 *    - OnboardingData 수신 (페르소나, 설정 등)
 *    - localStorage에 'onboarding_completed' = 'true' 저장
 *    - /chat 경로로 navigate
 * 3. OnboardingGuard가 localStorage 확인
 * 4. 온보딩 완료 플래그로 메인 앱 접근 허용
 * 
 * ## 온보딩 종료 로직
 * - handleExit() 실행
 * - 온보딩 데이터 저장하지 않음
 * - /chat 경로로 navigate
 * - ⚠️ OnboardingGuard가 리다이렉트할 수 있음 (온보딩 미완료 시)
 * 
 * ## 관련 파일
 * - 온보딩 플로우: 0108mlog-0109/src/components/onboarding/OnboardingFlow.tsx
 * - 온보딩 데이터 타입: 0108mlog-0109/src/components/onboarding/index.ts
 * - 가드: 0108mlog-0109/src/router/guards.tsx (OnboardingGuard)
 * - 라우터: 0108mlog-0109/src/router/Router.tsx
 * - UI: 0108mlog-0109/src/components/ui/NoiseOverlay.tsx
 * 
 * ## localStorage 키
 * - 'onboarding_completed': 'true' | null
 *   - 설정 위치: handleOnboardingComplete()
 *   - 확인 위치: guards.tsx의 useOnboardingStatus()
 * 
 * ## 위험요인
 * - ⚠️ localStorage 접근 실패: 사생활 보호 모드에서 저장 실패 가능
 *   - 현재: try-catch 없음 (guards.tsx에서만 처리)
 *   - 개선: try-catch로 에러 처리 또는 sessionStorage 폴백 검토
 * - ⚠️ handleExit()에서 데이터 미저장: 사용자가 종료 시 온보딩 재시작
 *   - 의도된 동작인지 확인 필요
 * - ⚠️ navigate('/chat') 후 OnboardingGuard 리다이렉트: 무한 루프 가능성
 *   - 현재: handleOnboardingComplete()에서만 'onboarding_completed' 설정
 *   - handleExit()에서는 설정하지 않음 → 다시 /onboarding으로 리다이렉트
 * - ✅ NoiseOverlay로 텍스처 효과 추가
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingFlow } from '../onboarding';
import type { OnboardingData } from '../onboarding';
import { NoiseOverlay } from '../ui';

/**
 * OnboardingLayout Props 인터페이스
 */
interface OnboardingLayoutProps {}

/**
 * OnboardingLayout 컴포넌트
 * 
 * @component
 * @param {OnboardingLayoutProps} props - 컴포넌트 props
 * @returns {JSX.Element} OnboardingLayout 컴포넌트
 */
export const OnboardingLayout: React.FC<OnboardingLayoutProps> = () => {
  const navigate = useNavigate();

  /**
   * 온보딩 완료 핸들러
   * 
   * @param data 온보딩 데이터 (페르소나, 설정 등)
   */
  const handleOnboardingComplete = (data: OnboardingData) => {
    // 온보딩 데이터 저장
    console.log('온보딩 완료:', data);
    localStorage.setItem('onboarding_completed', 'true');
    // 메인 화면으로 이동
    navigate('/chat');
  };

  /**
   * 온보딩 종료 핸들러
   * 
   * ⚠️ 주의: 데이터 미저장으로 다시 온보딩으로 리다이렉트됨
   */
  const handleExit = () => {
    // 종료 시 아무것도 저장하지 않고 앱 종료 (또는 홈으로 이동)
    // 실제로는 앱 종료 또는 홈 화면으로 이동
    navigate('/chat');
  };

  return (
    <div className="relative w-full h-screen-dynamic overflow-hidden font-sans bg-gradient-to-br from-brand-light via-white to-brand-secondary/20">
      <NoiseOverlay />
      <OnboardingFlow
        onComplete={handleOnboardingComplete}
        onExit={handleExit}
      />
    </div>
  );
};
