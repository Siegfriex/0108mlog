/**
 * 마음로그 V5.0 EmotionSelectModal 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/ui/EmotionSelectModal.tsx
 * - 역할: 감정 선택 및 강도 조절 모달
 * - 사용 위치: 체크인 플로우, 일기 작성 등
 * 
 * ## 감정 타입 (5개)
 * 1. JOY: 완전 최고 (Smile, amber)
 * 2. PEACE: 괜찮아요 (Meh, brand-primary)
 * 3. ANXIETY: 조금 불안해요 (Frown, orange)
 * 4. SADNESS: 우울해요 (CloudRain, indigo)
 * 5. ANGER: 화가 나요 (Flame, rose)
 * 
 * ## UI 구성
 * 
 * ### 1. 배경 오버레이
 * - bg-black/40 backdrop-blur-md
 * - z-modal (1000)
 * - 클릭 시: 모달 닫힘 (onComplete 콜백 없음)
 * 
 * ### 2. 글래스모피즘 모달
 * - GlassCard 컴포넌트 사용
 * - 중앙 배치: flex items-center justify-center
 * - 애니메이션: scale 0.8 → 1, opacity 0 → 1
 * 
 * ### 3. 감정 선택 버튼
 * - 5개 버튼 (2열 레이아웃)
 * - 선택 시: 배경 그라데이션 + 아이콘 색상 변경
 * - EmotionOrb 컴포넌트로 시각화
 * 
 * ### 4. 강도 슬라이더
 * - 1-10 범위 (1: 매우 약함, 10: 매우 강함)
 * - 슬라이더 색상: 감정에 따라 동적 변경
 * - 실시간 피드백: intensity 값 표시
 * 
 * ### 5. 완료 버튼
 * - 감정 선택 + 강도 조절 후 활성화
 * - onComplete 콜백 호출
 * 
 * ## 인터랙션
 * 
 * ### 키보드 네비게이션
 * - 화살표 키: 감정 선택 이동 (2열 그리드)
 * - Enter: 감정 선택
 * - Tab: 포커스 이동 (감정 → 슬라이더 → 완료)
 * - Escape: 모달 닫기
 * 
 * ### 포커스 관리
 * - useFocusTrap: 모달 내부로 포커스 제한
 * - useFocusRestore: 모달 닫힘 시 이전 포커스 복원
 * - 초기 포커스: 감정 선택 버튼
 * 
 * ## Z-Index
 * - 레이어: z-modal (1000)
 * - Portal 사용: body 직접 마운트
 * 
 * ## 접근성
 * - ARIA role: dialog
 * - ARIA label: "감정 선택"
 * - 키보드 네비게이션: 완전 지원
 * - 포커스 트랩: 모달 외부 접근 차단
 * 
 * ## 사용 위치
 * - 체크인 플로우 (checkin 컴포넌트)
 * - 일기 작성 (NightMode)
 * - 감정 기록 추가 (JournalDiary)
 * 
 * ## 관련 파일
 * - UI:
 *   - 0108mlog-0109/src/components/ui/GlassCard.tsx
 *   - 0108mlog-0109/src/components/ui/Button.tsx
 *   - 0108mlog-0109/src/components/ui/EmotionOrb.tsx
 *   - 0108mlog-0109/src/components/ui/Portal.tsx
 * - 훅:
 *   - 0108mlog-0109/src/hooks/useKeyboardNavigation.ts
 *   - 0108mlog-0109/src/hooks/useFocusTrap.ts
 *   - 0108mlog-0109/src/hooks/useFocusRestore.ts
 * - 타입: 0108mlog-0109/types/index.ts (EmotionType)
 * - Barrel export: 0108mlog-0109/src/components/ui/index.ts
 * 
 * ## 위험요인
 * - ⚠️ EMOTIONS_CONFIG: 하드코딩, 다국어 지원 시 수정 필요
 * - ⚠️ 2열 레이아웃: columns=2 고정, 반응형 고려 필요
 * - ⚠️ Portal 사용: body 직접 마운트, SSR 호환성 확인
 * - ⚠️ selectedIndex 동기화: useEffect로 selectedEmotion 변경 시 업데이트
 *   - 초기 렌더링 시 깜박임 가능
 * - ✅ 포커스 관리: 접근성 우수
 * - ✅ 키보드 네비게이션: 완전 지원
 * - ✅ Framer Motion: 부드러운 애니메이션
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GlassCard, Button, EmotionOrb, Portal } from './index';
import { EmotionType } from '../../../types';
import { Smile, Meh, Frown, CloudRain, Flame } from 'lucide-react';
import { useKeyboardNavigation } from '../../hooks/useKeyboardNavigation';
import { useFocusTrap } from '../../hooks/useFocusTrap';
import { useFocusRestore } from '../../hooks/useFocusRestore';

/**
 * 감정 설정 구성
 */
const EMOTIONS_CONFIG = [
  { id: EmotionType.JOY, label: '완전 최고', icon: <Smile size={36} strokeWidth={2} />, color: 'text-amber-500', bgGradient: 'from-amber-200/40 via-yellow-100/40 to-orange-100/40' },
  { id: EmotionType.PEACE, label: '괜찮아요', icon: <Meh size={36} strokeWidth={2} />, color: 'text-brand-primary', bgGradient: 'from-brand-secondary/40 via-teal-100/40 to-cyan-100/40' },
  { id: EmotionType.ANXIETY, label: '조금 불안해요', icon: <Frown size={36} strokeWidth={2} />, color: 'text-orange-500', bgGradient: 'from-orange-200/40 via-red-100/40 to-amber-100/40' },
  { id: EmotionType.SADNESS, label: '우울해요', icon: <CloudRain size={36} strokeWidth={2} />, color: 'text-indigo-500', bgGradient: 'from-indigo-200/40 via-purple-100/40 to-slate-100/40' },
  { id: EmotionType.ANGER, label: '화가 나요', icon: <Flame size={36} strokeWidth={2} />, color: 'text-rose-500', bgGradient: 'from-rose-200/40 via-red-100/40 to-orange-100/40' },
];

export interface EmotionSelectModalProps {
  isOpen: boolean;
  selectedEmotion: EmotionType | null;
  intensity: number;
  onEmotionSelect: (emotion: EmotionType) => void;
  onIntensityChange: (intensity: number) => void;
  onComplete: () => void;
}

/**
 * 감정 선택 모달 컴포넌트
 * 글래스모피즘 스타일의 중앙 모달로 감정과 강도 선택
 */
export const EmotionSelectModal: React.FC<EmotionSelectModalProps> = ({
  isOpen,
  selectedEmotion,
  intensity,
  onEmotionSelect,
  onIntensityChange,
  onComplete,
}) => {
  // 키보드 네비게이션을 위한 선택 인덱스
  const [selectedIndex, setSelectedIndex] = useState(0);
  const modalContainerRef = useRef<HTMLDivElement>(null);

  // 선택된 감정에 맞춰 인덱스 동기화
  useEffect(() => {
    if (selectedEmotion) {
      const index = EMOTIONS_CONFIG.findIndex(e => e.id === selectedEmotion);
      if (index !== -1) {
        setSelectedIndex(index);
      }
    }
  }, [selectedEmotion]);

  // 키보드 네비게이션 Hook 적용
  const { containerRef } = useKeyboardNavigation({
    itemCount: EMOTIONS_CONFIG.length,
    selectedIndex,
    onSelectChange: setSelectedIndex,
    onEnter: (index) => {
      onEmotionSelect(EMOTIONS_CONFIG[index].id);
    },
    enabled: isOpen,
    columns: 2, // 모바일 2열, 데스크탑에서는 flex-wrap으로 자동 조정
    loop: true,
    horizontal: true,
    vertical: true,
  });

  // 포커스 트랩 적용
  useFocusTrap({
    enabled: isOpen,
    containerRef: modalContainerRef,
    initialFocusSelector: 'button[aria-label*="감정 선택"]',
  });

  // 포커스 복원 적용
  useFocusRestore({
    shouldRestore: !isOpen,
  });

  return (
    <Portal>
      <AnimatePresence>
        {isOpen && (
          <>
            {/* 배경 오버레이 */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-md z-modal flex items-center justify-center p-4"
            >
            {/* 글래스모피즘 모달 */}
            <motion.div
              ref={modalContainerRef}
              initial={{ scale: 0.8, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 50 }}
              transition={{ 
                type: 'spring',
                stiffness: 300,
                damping: 30,
                duration: 0.5
              }}
              className="w-full max-w-md"
            >
              <GlassCard 
                intensity="high" 
                enableSpotlight={true}
                enableTilt={true}
                className="p-8 relative overflow-hidden"
              >
                {/* 배경 그라데이션 효과 */}
                <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/10 via-brand-secondary/5 to-transparent pointer-events-none" />
                
                <div className="relative z-content-base">
                  {/* 헤더 */}
                  <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-center mb-8"
                  >
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">
                      오늘 기분이 어떠신가요?
                    </h2>
                    <p className="text-sm text-slate-600">
                      감정을 선택하고 강도를 조절해주세요
                    </p>
                  </motion.div>

                  {/* 감정 선택 그리드 */}
                  <motion.div
                    ref={containerRef as React.RefObject<HTMLDivElement>}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="flex flex-wrap justify-center gap-4 mb-8"
                    tabIndex={-1}
                  >
                    {EMOTIONS_CONFIG.map((emotion, index) => {
                      const isSelected = selectedEmotion === emotion.id;
                      const isFocused = selectedIndex === index;
                      return (
                        <motion.div
                          key={emotion.id}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <EmotionOrb
                            emotion={emotion.id}
                            icon={emotion.icon}
                            label={emotion.label}
                            color={emotion.color}
                            bgGradient={emotion.bgGradient}
                            isSelected={isSelected}
                            onClick={() => {
                              setSelectedIndex(index);
                              onEmotionSelect(emotion.id);
                            }}
                          />
                        </motion.div>
                      );
                    })}
                  </motion.div>

                  {/* 강도 슬라이더 */}
                  {selectedEmotion && (
                    <motion.div
                      initial={{ opacity: 0, height: 0, y: -10 }}
                      animate={{ opacity: 1, height: 'auto', y: 0 }}
                      exit={{ opacity: 0, height: 0, y: -10 }}
                      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                      className="mb-8"
                    >
                      <label className="block text-sm font-semibold text-slate-700 mb-4 text-center">
                        강도: <span className="text-brand-primary text-xl font-bold">{intensity}</span>/10
                      </label>
                      <div className="relative px-2">
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={intensity}
                          onChange={(e) => onIntensityChange(Number(e.target.value))}
                          className="slider w-full h-3 rounded-full appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between mt-3 text-xs text-slate-500 font-medium">
                          <span>약함</span>
                          <span>보통</span>
                          <span>강함</span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* 시작 버튼 */}
                  {selectedEmotion && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                    >
                      <Button
                        onClick={onComplete}
                        variant="primary"
                        className="w-full h-12 text-base font-semibold shadow-lg shadow-brand-primary/30"
                      >
                        대화 시작하기
                      </Button>
                    </motion.div>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
          </>
        )}
      </AnimatePresence>
    </Portal>
  );
};
