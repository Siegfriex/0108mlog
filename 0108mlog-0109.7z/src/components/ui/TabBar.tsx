/**
 * 마음로그 V5.0 TabBar 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/ui/TabBar.tsx
 * - 역할: 하단 네비게이션 탭 바 (Dock)
 * - 사용 위치: 0108mlog-0109/src/components/layout/MainLayout.tsx
 * 
 * ## 탭 구성 (5개)
 * 1. chat: 채팅 (MessageCircle)
 * 2. journal: 기록 (Book)
 * 3. reports: 통계 (BarChart2)
 * 4. content: 피드 (Layers)
 * 5. profile: 나 (User)
 * 
 * ## 인터랙션
 * 
 * ### 터치 제스처
 * - 스와이프 왼쪽: 다음 탭 (순환)
 * - 스와이프 오른쪽: 이전 탭 (순환)
 * - 탭: 햅틱 피드백 (light)
 * 
 * ### 키보드 네비게이션
 * - 화살표 좌우: 탭 이동 (순환)
 * - Home: 첫 탭 (chat)
 * - End: 마지막 탭 (profile)
 * - Enter/Space: 탭 활성화
 * 
 * ## 스타일링
 * - 글래스모피즘: backdrop-blur-2xl, bg-white/80 (day) / bg-white/10 (night)
 * - Floating Indicator: 활성 탭 배경 애니메이션 (layoutId="tab-indicator")
 * - 라벨 색상: 활성 (brand-primary) / 비활성 (opacity-60)
 * 
 * ## Z-Index
 * - 레이어: z-dock (50)
 * - 위치: MainLayout Dock 영역
 * 
 * ## 접근성
 * - ARIA role: navigation
 * - ARIA current: page (활성 탭)
 * - 키보드 포커스: ref 배열 관리
 * 
 * ## 관련 파일
 * - 레이아웃: 0108mlog-0109/src/components/layout/MainLayout.tsx
 * - 훅:
 *   - 0108mlog-0109/src/hooks/useTouchGestures.ts
 *   - 0108mlog-0109/src/hooks/useHaptics.ts
 * - Barrel export: 0108mlog-0109/src/components/ui/index.ts
 * 
 * ## 위험요인
 * - ⚠️ buttonRefs 배열: 5개 고정 (탭 수 변경 시 수정 필요)
 * - ⚠️ 스와이프 제스처: 페이지 내 스크롤과 충돌 가능
 *   - useTouchGestures에서 threshold로 제어
 * - ⚠️ Floating Indicator: layoutId 충돌 주의
 *   - 현재: "tab-indicator" 고유 ID 사용
 * - ✅ 키보드 네비게이션: 접근성 우수
 * - ✅ 햅틱 피드백: 모바일 사용자 경험 향상
 */

import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Book, BarChart2, Layers, User } from 'lucide-react';
import { useTouchGestures } from '../../hooks/useTouchGestures';
import { useHaptics } from '../../hooks/useHaptics';
export interface TabBarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  mode?: 'day' | 'night';
}

export const TabBar: React.FC<TabBarProps> = ({ 
  activeTab, 
  onTabChange, 
  mode = 'day' 
}) => {
  const allTabs = [
    { id: 'chat', label: '채팅', icon: <MessageCircle size={22} strokeWidth={2.5} /> },
    { id: 'journal', label: '기록', icon: <Book size={22} strokeWidth={2.5} /> },
    { id: 'reports', label: '통계', icon: <BarChart2 size={22} strokeWidth={2.5} /> },
    { id: 'content', label: '피드', icon: <Layers size={22} strokeWidth={2.5} /> },
    { id: 'profile', label: '나', icon: <User size={22} strokeWidth={2.5} /> },
  ];

  const activeIndex = allTabs.findIndex(tab => tab.id === activeTab);
  const buttonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const { triggerHaptic } = useHaptics();

  // 터치 제스처 핸들러
  const handleSwipeLeft = () => {
    const nextIndex = activeIndex < allTabs.length - 1 ? activeIndex + 1 : 0;
    onTabChange(allTabs[nextIndex].id);
    triggerHaptic('light');
  };

  const handleSwipeRight = () => {
    const prevIndex = activeIndex > 0 ? activeIndex - 1 : allTabs.length - 1;
    onTabChange(allTabs[prevIndex].id);
    triggerHaptic('light');
  };

  // 터치 제스처 통합
  const touchGestures = useTouchGestures({
    onSwipeLeft: handleSwipeLeft,
    onSwipeRight: handleSwipeRight,
  });

  // 키보드 네비게이션 핸들러
  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    let newIndex = index;

    switch (e.key) {
      case 'ArrowLeft':
        e.preventDefault();
        newIndex = index > 0 ? index - 1 : allTabs.length - 1;
        break;
      case 'ArrowRight':
        e.preventDefault();
        newIndex = index < allTabs.length - 1 ? index + 1 : 0;
        break;
      case 'Home':
        e.preventDefault();
        newIndex = 0;
        break;
      case 'End':
        e.preventDefault();
        newIndex = allTabs.length - 1;
        break;
      case 'Enter':
      case ' ':
        e.preventDefault();
        onTabChange(allTabs[index].id);
        return;
      default:
        return;
    }

    // 포커스 이동
    buttonRefs.current[newIndex]?.focus();
    onTabChange(allTabs[newIndex].id);
  };

  return (
    <nav 
      {...touchGestures}
      className={`
        relative flex items-center justify-between px-6 py-3 gap-2 pb-safe-bottom
        backdrop-blur-2xl border
        rounded-xl shadow-2xl
        w-auto min-w-80 max-w-full transition-colors duration-500
        ${mode === 'day' 
          ? 'bg-white/80 border-white/60 shadow-brand-primary/10 ring-1 ring-white/50' 
          : 'bg-slate-900/80 border-white/10 shadow-black/50 ring-1 ring-white/10'
        }
      `}
      role="navigation"
      aria-label="메인 네비게이션"
    >
      {/* 유동적 배경 (젤리처럼 이동) */}
      {allTabs.map((tab, index) => {
        const isActive = activeTab === tab.id;
        if (!isActive) return null;
        
        return (
          <motion.div
            key={`background-${tab.id}`}
            layoutId="activeTabBackground"
            className={`
              absolute inset-0 rounded-xl
              ${mode === 'day' 
                ? 'bg-brand-light/50' 
                : 'bg-white/10'
              }
            `}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 30,
            }}
            style={{
              left: `${index * (100 / allTabs.length)}%`,
              width: `${100 / allTabs.length}%`,
            }}
          />
        );
      })}
      
      {allTabs.map((tab, index) => {
        const isActive = activeTab === tab.id;
        
        return (
          <motion.button
            key={tab.id}
            ref={(el) => { buttonRefs.current[index] = el; }}
            onClick={() => {
              onTabChange(tab.id);
              triggerHaptic('light');
            }}
            onKeyDown={(e) => handleKeyDown(e, index)}
            whileTap={{ scale: 0.9 }}
            tabIndex={isActive ? 0 : -1}
            className={`
              relative z-content-base group flex flex-col items-center justify-center
              w-11 h-11 rounded-xl
              transition-all duration-300
              focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2
              ${isActive 
                ? mode === 'day' 
                  ? 'text-brand-primary shadow-sm' 
                  : 'text-brand-secondary'
                : mode === 'day' 
                  ? 'text-slate-400 hover:text-brand-dark' 
                  : 'text-slate-500 hover:text-slate-300'
              }
            `}
            aria-label={tab.label}
            aria-current={isActive ? 'page' : undefined}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            {tab.icon}
            
            {/* 활성 탭 표시 점 */}
            {isActive && (
              <motion.div 
                layoutId="activeTabDot"
                className={`absolute -bottom-2 w-1 h-1 rounded-full ${mode === 'day' ? 'bg-brand-primary' : 'bg-brand-secondary'}`}
              />
            )}
          </motion.button>
        );
      })}
    </nav>
  );
};
