/**
 * 마음로그 V5.0 ErrorBoundary 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/ui/ErrorBoundary.tsx
 * - 역할: React 런타임 에러 캐치 및 Fallback UI 표시
 * - 사용 위치: 0108mlog-0109/src/router/Router.tsx (최상위 래퍼)
 * 
 * ## 에러 처리 전략
 * 
 * ### 1. 에러 캐치
 * - componentDidCatch(): React 에러 라이프사이클
 * - getDerivedStateFromError(): 에러 발생 시 상태 업데이트
 * - 에러 로깅: console.error() (추후 Sentry 연동 가능)
 * 
 * ### 2. Fallback UI
 * - 커스텀 fallback prop이 있으면 사용
 * - 없으면 기본 에러 화면 표시
 * - 기본 에러 화면:
 *   - AlertCircle 아이콘
 *   - "문제가 발생했습니다" 제목
 *   - 재시도 버튼 (handleRetry)
 *   - 홈으로 가기 버튼 (handleGoHome)
 * 
 * ### 3. 개발 모드 디버깅
 * - process.env.NODE_ENV === 'development'
 * - 에러 메시지 및 스택 트레이스 표시
 * - <details> 태그로 확장 가능한 컴포넌트 스택
 * 
 * ## 복구 방법
 * 
 * ### handleRetry()
 * - 상태 초기화: hasError, error, errorInfo를 null로 설정
 * - 자식 컴포넌트 재렌더링 시도
 * - ⚠️ 에러 원인 미해결 시 재발 가능
 * 
 * ### handleGoHome()
 * - window.location.href = '/'
 * - 전체 페이지 리로드
 * - ✅ 에러 상태 완전 초기화
 * 
 * ## 에러 바운더리 제약사항
 * - 이벤트 핸들러 에러: 캐치 불가 (try-catch 사용)
 * - 비동기 코드: 캐치 불가 (Promise rejection)
 * - 서버 사이드 렌더링: 캐치 불가
 * - ErrorBoundary 자체 에러: 캐치 불가
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/router/Router.tsx (AppRouter 최상위)
 * - 필요 시 개별 컴포넌트에 추가 가능
 * 
 * ## 관련 파일
 * - 라우터: 0108mlog-0109/src/router/Router.tsx
 * - UI: 0108mlog-0109/src/components/ui/Button.tsx
 * - Barrel export: 0108mlog-0109/src/components/ui/index.ts
 * 
 * ## 위험요인
 * - ⚠️ 에러 로깅: console.error만 사용
 *   - 개선: Sentry, LogRocket 등 에러 추적 서비스 연동
 * - ⚠️ handleRetry(): 에러 재발 가능
 *   - 원인 미해결 시 무한 루프 위험
 * - ⚠️ window.location.href: 앱 상태 완전 초기화
 *   - 사용자 데이터 손실 가능 (미저장 상태)
 * - ⚠️ 개발 모드 에러 표시: 프로덕션에서는 숨김
 *   - 사용자에게 기술 정보 노출 방지
 * - ✅ 최상위 래퍼: 앱 크래시 방지
 * - ✅ 사용자 친화적 UI: 에러 메시지 간소화
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw, Home } from 'lucide-react';
import { Button } from './Button';

/**
 * ErrorBoundary Props 인터페이스
 */
interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * ErrorBoundary State 인터페이스
 */
interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

/**
 * ErrorBoundary 컴포넌트
 * 
 * React 런타임 에러를 캐치하여 앱 크래시를 방지하고
 * 사용자 친화적인 에러 화면을 표시합니다.
 * 
 * @component
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // 에러 로깅 (추후 에러 추적 서비스 연동 가능)
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    this.setState({
      error,
      errorInfo,
    });
  }

  handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      // 커스텀 fallback이 제공된 경우 사용
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // 기본 에러 화면
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
          <div className="max-w-md w-full bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
            </div>
            
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
              문제가 발생했습니다
            </h1>
            
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              예상치 못한 오류가 발생했습니다. 다시 시도해주세요.
            </p>

            {process.env.NODE_ENV === 'development' && this.state.error && (
              <div className="mb-6 p-4 bg-slate-100 dark:bg-slate-700 rounded-lg text-left">
                <p className="text-xs font-mono text-red-600 dark:text-red-400 break-all">
                  {this.state.error.toString()}
                </p>
                {this.state.errorInfo && (
                  <details className="mt-2">
                    <summary className="text-xs text-slate-500 dark:text-slate-400 cursor-pointer">
                      스택 트레이스 보기
                    </summary>
                    <pre className="mt-2 text-xs text-slate-600 dark:text-slate-300 overflow-auto max-h-40">
                      {this.state.errorInfo.componentStack}
                    </pre>
                  </details>
                )}
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <Button
                onClick={this.handleRetry}
                variant="primary"
                className="flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                다시 시도
              </Button>
              
              <Button
                onClick={this.handleGoHome}
                variant="secondary"
                className="flex items-center gap-2"
              >
                <Home className="w-4 h-4" />
                홈으로
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
