import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Sparkles, CheckCircle, ArrowRight, Smile, Meh, Frown, CloudRain, Flame } from 'lucide-react';
import { GlassCard, Button, CelestialBackground } from '../ui';
import { VoicePlayer } from './VoicePlayer';
import { CoachPersona, TimelineEntry, EmotionType } from '../../../types';
import { useNightCheckinMachine } from '../../features/checkin/useNightCheckinMachine';
import { useKeyboardNavigation } from '../../hooks/useKeyboardNavigation';

interface NightModeProps {
  persona: CoachPersona;
  onSave: (entry: TimelineEntry) => void;
  onCrisisDetected?: () => void;
  onEmotionChange?: (emotion: EmotionType | null) => void;
}

// 밤 모드용 감정 설정 (흰색/밝은 스타일)
const NIGHT_EMOTIONS = [
    { id: EmotionType.JOY, label: '기쁨', icon: <Smile size={40} strokeWidth={1.5} />, color: 'joy' },
    { id: EmotionType.PEACE, label: '평온', icon: <Meh size={40} strokeWidth={1.5} />, color: 'peace' },
    { id: EmotionType.ANXIETY, label: '불안', icon: <Frown size={40} strokeWidth={1.5} />, color: 'anxiety' },
    { id: EmotionType.SADNESS, label: '슬픔', icon: <CloudRain size={40} strokeWidth={1.5} />, color: 'sadness' },
    { id: EmotionType.ANGER, label: '분노', icon: <Flame size={40} strokeWidth={1.5} />, color: 'anger' },
];

/**
 * 마음로그 V5.0 NightMode 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/chat/NightMode.tsx
 * - 역할: Night Mode 일기 작성 및 편지 생성
 * - 기능: FEAT-001 (대화형 감정 체크인)
 * - PRD: 플로우차트 2.2 (Night Mode 체크인 플로우)
 * 
 * ## 상태 머신 플로우
 * 1. EMOTION: 감정 선택 (5가지 감정)
 * 2. DIARY: 일기 작성 (자유 텍스트)
 * 3. LETTER: 편지 생성 (AI 응답)
 * 4. COMPLETED: 저장 완료
 * 
 * ## 엔드포인트 연결
 * ### generateNightModeLetter
 * - 호출: useNightCheckinMachine → gemini.ts
 * - 경로: analyzeDiary() → generateNightModeLetter()
 * - Firebase Functions: generateNightModeLetter (asia-northeast3)
 * - 파라미터:
 *   - diaryEntry: string (일기 원문)
 *   - persona: CoachPersona (페르소나 설정)
 * - 응답: 편지 텍스트
 * - 타임아웃: 8초, 재시도: 3회
 * 
 * ## UI 구성
 * 
 * ### 1. 감정 선택 단계
 * - 5개 감정 버튼 (2열 그리드)
 * - 키보드 네비게이션 지원
 * - CelestialBackground (천체 배경)
 * 
 * ### 2. 일기 작성 단계
 * - Textarea (자유 텍스트)
 * - Placeholder: "오늘 하루를 돌아보며..."
 * - 분석 버튼: AI 편지 생성
 * 
 * ### 3. 편지 단계
 * - AI 생성 편지 표시
 * - VoicePlayer (TTS 읽기)
 * - 저장 버튼
 * - 재생성 버튼
 * 
 * ## 스타일링
 * - 다크 테마: text-white, bg-transparent
 * - 글래스모피즘: backdrop-blur-md, bg-white/10
 * - 천체 배경: CelestialBackground (별/행성/혜성)
 * - 애니메이션: Framer Motion (step 전환)
 * 
 * ## 상태 관리
 * - 상태 머신: useNightCheckinMachine (XState 기반)
 * - 상태:
 *   - currentStep: 'emotion' | 'diary' | 'letter'
 *   - emotion: EmotionType | null
 *   - diary: string
 *   - letter: string
 *   - isGeneratingLetter: boolean
 * 
 * ## 저장 로직
 * - TimelineEntry 생성:
 *   - emotion
 *   - diary (원문)
 *   - letter (AI 생성)
 *   - timestamp
 * - Firestore 저장: saveDiaryEntry()
 * - 동의 확인: canSaveConversation()
 *   - 동의 없으면: 감정 수치만 저장, 원문 스킵
 * 
 * ## 위기 감지
 * - 일기 원문 분석: detectCrisisByKeyword()
 * - 감지 시: onCrisisDetected() 콜백
 * - 편지 생성 전 감지
 * 
 * ## 접근성
 * - 키보드 네비게이션: useKeyboardNavigation
 * - 화살표 키: 감정 선택 이동
 * - Enter: 감정 선택 확정
 * - Tab: 단계 간 이동
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/pages/chat/ChatMain.tsx
 * 
 * ## 관련 파일
 * - 상태 머신: 0108mlog-0109/src/features/checkin/useNightCheckinMachine.ts
 * - AI 서비스: 0108mlog-0109/src/services/ai/gemini.ts
 * - 위기 감지: 0108mlog-0109/src/services/crisisDetection.ts
 * - Firestore: 0108mlog-0109/src/services/firestore.ts
 * - UI:
 *   - 0108mlog-0109/src/components/ui/CelestialBackground.tsx
 *   - 0108mlog-0109/src/components/ui/GlassCard.tsx
 *   - 0108mlog-0109/src/components/chat/VoicePlayer.tsx
 * - 훅: 0108mlog-0109/src/hooks/useKeyboardNavigation.ts
 * 
 * ## 위험요인
 * - ⚠️ AI 편지 생성 지연: 타임아웃 8초, 최대 24초 소요 가능 (재시도 3회)
 *   - 사용자가 일기 작성 후 대기 시간 증가
 * - ⚠️ 일기 원문 저장: 동의 확인 필수
 *   - Privacy-first 모델 준수
 * - ⚠️ Textarea 높이: 고정 높이 없음, 긴 일기 시 레이아웃 깨짐 가능
 *   - 개선: maxHeight 또는 스크롤 추가
 * - ⚠️ VoicePlayer TTS: 브라우저 호환성
 *   - Web Speech API 지원 확인 필요
 * - ⚠️ CelestialBackground 성능: 애니메이션 부하
 *   - 저사양 기기에서 프레임 드롭 가능
 * - ✅ 키보드 네비게이션: 접근성 우수
 * - ✅ 천체 배경: Night Mode 몰입감 향상
 * - ✅ 단계별 애니메이션: 사용자 경험 향상
 */
export const NightMode: React.FC<NightModeProps> = ({ persona, onSave, onCrisisDetected, onEmotionChange }) => {
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  
  // 상태 머신 훅 사용
  const machine = useNightCheckinMachine({
    persona,
    onCrisisDetected,
    onComplete: (entry) => {
      onSave(entry);
      setShowSaveConfirm(true);
      setTimeout(() => setShowSaveConfirm(false), 3000);
    },
    onEmotionChange,
  });

  // 현재 단계 (상태 머신에서 추출)
  const step = machine.currentStep;

  // 선택된 감정에 맞춰 인덱스 동기화
  useEffect(() => {
    if (machine.emotion) {
      const index = NIGHT_EMOTIONS.findIndex(e => e.id === machine.emotion);
      if (index !== -1) {
        setSelectedIndex(index);
      }
    }
  }, [machine.emotion]);

  // 키보드 네비게이션 Hook 적용 (감정 선택 단계에서만 활성화)
  const { containerRef } = useKeyboardNavigation({
    itemCount: NIGHT_EMOTIONS.length,
    selectedIndex,
    onSelectChange: setSelectedIndex,
    onEnter: (index) => {
      machine.selectEmotion(NIGHT_EMOTIONS[index].id);
    },
    enabled: step === 'emotion',
    columns: 2, // 모바일 2열, 데스크탑 3열
    loop: true,
    horizontal: true,
    vertical: true,
  });

  /**
   * 다음 단계로 이동
   */
  const handleNextStep = async () => {
    if (step === 'emotion' && machine.emotion) {
      await machine.nextToDiary();
    }
  };

  /**
   * 일기 분석 및 편지 생성
   */
  const handleAnalyze = async () => {
    if (!machine.diary.trim()) return;
    await machine.analyzeDiary();
  };

  return (
    <div className="w-full max-w-4xl mx-auto h-full flex flex-col px-4 text-white relative overflow-hidden">
      {/* 천체 배경 */}
      <CelestialBackground intensity="medium" />
      
      {/* Title */}
      <div className="py-6 shrink-0 text-center">
          <h2 className="text-2xl font-serif font-bold flex items-center justify-center gap-2 mb-2 drop-shadow-md">
            <span className="text-purple-300"><Star size={20} fill="currentColor" /></span>
            {step === 'emotion' ? '저녁 성찰' : step === 'diary' ? '나의 이야기' : '당신을 위한 편지'}
          </h2>
          <p className="text-white/60 text-sm font-medium">
             {step === 'emotion' ? '오늘 하루 기분은 어떠셨나요?' : 
              step === 'diary' ? '모두 털어놓으세요. 밤이 듣고 있어요.' : 
              `${persona.name}의 메시지`}
          </p>
      </div>

      <AnimatePresence mode="wait">
        {step === 'emotion' && (
            <motion.div
                key="step-emotion"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1 flex flex-col justify-center items-center gap-8 max-w-2xl mx-auto w-full"
            >
                <div 
                    ref={containerRef as React.RefObject<HTMLDivElement>}
                    className="grid grid-cols-2 md:grid-cols-3 gap-6 w-full"
                    tabIndex={-1}
                >
                    {NIGHT_EMOTIONS.map((emotion, index) => {
                        const isSelected = machine.emotion === emotion.id;
                        const isFocused = selectedIndex === index;
                        return (
                            <button
                                key={emotion.id}
                                onClick={() => {
                                    setSelectedIndex(index);
                                    machine.selectEmotion(emotion.id);
                                }}
                                className={`
                                    aspect-square p-6 rounded-lg backdrop-blur-md border text-left transition-all duration-300 flex flex-col justify-center items-center gap-4 group
                                    focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-transparent
                                    ${isSelected 
                                        ? 'bg-white/20 border-white/60 shadow-glow-white scale-105 ring-1 ring-white/50' 
                                        : 'bg-white/5 border-white/5 hover:bg-white/10'
                                    }
                                    ${isFocused && !isSelected ? 'ring-2 ring-white/30 ring-offset-2 ring-offset-transparent' : ''}
                                `}
                                tabIndex={isFocused ? 0 : -1}
                            >
                                <span className="text-white/80 group-hover:scale-110 transition-transform duration-300">{emotion.icon}</span>
                                <span className="text-white/90 font-medium text-lg tracking-wide">{emotion.label}</span>
                            </button>
                        );
                    })}
                </div>

                {machine.emotion && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-white/5 backdrop-blur-xl rounded-lg p-8 border border-white/10 w-full"
                    >
                         <div className="flex justify-between text-white font-bold mb-6">
                             <span className="text-xs uppercase tracking-wider text-purple-200">감정 깊이</span>
                             <span className="text-xl">{machine.intensity}</span>
                         </div>
                         <input 
                            type="range" 
                            min="1" 
                            max="10" 
                            value={machine.intensity} 
                            onChange={(e) => machine.changeIntensity(Number(e.target.value))}
                            className="w-full h-2 bg-white/20 rounded-full appearance-none cursor-pointer accent-purple-300"
                        />
                        <Button 
                          onClick={handleNextStep} 
                          className="w-full mt-8 py-4 bg-purple-500 hover:bg-purple-600 border-none text-white font-bold text-lg shadow-xl shadow-purple-900/40"
                          aria-label="다음 단계로 계속하기"
                        >
                            계속하기 <ArrowRight size={20} />
                        </Button>
                    </motion.div>
                )}
            </motion.div>
        )}

        {step === 'diary' && (
             <motion.div
                key="step-diary"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1 flex flex-col gap-6 w-full max-w-3xl mx-auto pb-10"
            >
                {/* Day Mode 요약 표시 */}
                {machine.dayModeSummary && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-purple-500/20 backdrop-blur-md rounded-lg p-4 border border-purple-300/20"
                  >
                    <p className="text-purple-200 text-sm font-medium mb-1">오늘 낮의 기록</p>
                    <p className="text-white/80 text-sm">{machine.dayModeSummary}</p>
                  </motion.div>
                )}

                <GlassCard className="flex-1 !bg-black/20 !border-white/10 !rounded-2xl overflow-hidden min-h-card shadow-2xl backdrop-blur-md">
                    <textarea
                      value={machine.diary}
                      onChange={(e) => machine.updateDiary(e.target.value)}
                      placeholder="오늘 하루를 기록해보세요..."
                      className="w-full h-full bg-transparent resize-none focus:outline-none text-white placeholder:text-white/20 text-xl leading-relaxed p-4 font-serif"
                      autoFocus
                    />
                </GlassCard>

                <Button 
                    onClick={handleAnalyze} 
                    isLoading={machine.isAnalyzing}
                    className="w-full py-5 bg-gradient-to-r from-purple-600 to-indigo-600 shadow-lg border-none text-lg font-bold rounded-xl"
                    aria-label="일기 분석 및 편지 생성"
                >
                    <Sparkles className="w-5 h-5 mr-2" />
                    별에게 보내기
                </Button>
            </motion.div>
        )}

        {step === 'letter' && (
            <motion.div
                key="step-letter"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex-1 flex flex-col h-full overflow-hidden pb-10 w-full max-w-3xl mx-auto"
            >
                <GlassCard className="h-full flex flex-col !bg-indigo-950/60 !border-white/10 !rounded-2xl !p-8 shadow-2xl backdrop-blur-xl">
                    <div className="flex justify-between items-start mb-8 shrink-0 pb-6 border-b border-white/5">
                        <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-full bg-indigo-500/50 flex items-center justify-center shadow-lg border border-white/10">
                                <Sparkles size={24} className="text-purple-200" />
                            </div>
                            <div>
                                <h3 className="text-white font-bold text-lg">보낸이. {persona.name}</h3>
                                <span className="text-indigo-300 text-xs font-medium uppercase tracking-wider">인공지능 {persona.role}</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <VoicePlayer text={machine.letter} />
                        </div>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto pr-4 scrollbar-hide">
                        <div className="prose prose-lg prose-invert prose-p:text-indigo-100 prose-p:leading-loose prose-p:font-light font-serif">
                            <p className="whitespace-pre-wrap">{machine.letter}</p>
                        </div>
                    </div>

                    <div className="pt-6 mt-6 border-t border-white/5 shrink-0">
                        <Button 
                            variant="ghost" 
                            onClick={machine.reset}
                            className="w-full text-indigo-300 hover:text-white hover:bg-white/5 py-4 text-base"
                            aria-label="새 기록 시작하기"
                        >
                            새 기록 시작하기
                        </Button>
                    </div>
                </GlassCard>
            </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showSaveConfirm && (
             <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="fixed top-24 left-1/2 -translate-x-1/2 z-popover flex items-center gap-3 px-6 py-3 bg-emerald-500/90 backdrop-blur-xl text-white rounded-full shadow-2xl border border-white/20"
             >
                 <CheckCircle size={20} />
                 <span className="font-bold text-sm">저장되었습니다</span>
             </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
