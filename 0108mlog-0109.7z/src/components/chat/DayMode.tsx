import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Smile, Frown, Meh, CloudRain, Flame, Send, Heart, MessageCircle } from 'lucide-react';
import { GlassCard, Button } from '../ui';
import { EmotionSelectModal } from '../ui/EmotionSelectModal';
import { AIThinkingAnimation } from '../ui/AIThinkingAnimation';
import { SmartContextTag } from '../checkin';
import { QuickChip } from './QuickChip';
import { ActionFeedback } from '../actions/ActionFeedback';
import { EmotionType, CoachPersona, TimelineEntry } from '../../../types';
import { useDayCheckinMachine } from '../../features/checkin/useDayCheckinMachine';
import { useHaptics } from '../../hooks/useHaptics';

/**
 * 감정 설정 구성
 * PRD 명세에 따른 5가지 감정 타입 (JOY, PEACE, ANXIETY, SADNESS, ANGER)
 */
const EMOTIONS_CONFIG = [
  { id: EmotionType.JOY, label: '완전 최고', icon: <Smile size={36} strokeWidth={2} />, color: 'text-amber-500', bgGradient: 'from-amber-200/40 via-yellow-100/40 to-orange-100/40' },
  { id: EmotionType.PEACE, label: '괜찮아요', icon: <Meh size={36} strokeWidth={2} />, color: 'text-brand-primary', bgGradient: 'from-brand-secondary/40 via-teal-100/40 to-cyan-100/40' },
  { id: EmotionType.ANXIETY, label: '조금 불안해요', icon: <Frown size={36} strokeWidth={2} />, color: 'text-orange-500', bgGradient: 'from-orange-200/40 via-red-100/40 to-amber-100/40' },
  { id: EmotionType.SADNESS, label: '우울해요', icon: <CloudRain size={36} strokeWidth={2} />, color: 'text-indigo-500', bgGradient: 'from-indigo-200/40 via-purple-100/40 to-slate-100/40' },
  { id: EmotionType.ANGER, label: '화가 나요', icon: <Flame size={36} strokeWidth={2} />, color: 'text-rose-500', bgGradient: 'from-rose-200/40 via-red-100/40 to-orange-100/40' },
];

/**
 * 퀵칩 메시지 옵션
 */
const QUICK_CHIPS = [
  { id: '1', text: '오늘 하루는 어땠어요?', emotion: null },
  { id: '2', text: '무엇이 기분에 영향을 줬나요?', emotion: null },
  { id: '3', text: '지금 가장 필요한 건 뭐예요?', emotion: null },
];

/**
 * DayMode 컴포넌트 Props 인터페이스
 */
interface DayModeProps {
  persona: CoachPersona;
  onSave: (entry: TimelineEntry) => void;
  setImmersive: (active: boolean) => void;
  onNavigateToReports?: () => void;
  onOpenSafety?: () => void;
  onCrisisDetected?: () => void;
  onEmotionChange?: (emotion: EmotionType | null) => void;
}

/**
 * 마음로그 V5.0 DayMode 컴포넌트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/src/components/chat/DayMode.tsx
 * - 역할: Day Mode 대화형 감정 체크인
 * - 기능: FEAT-001 (대화형 감정 체크인)
 * - PRD: 플로우차트 2.1 (Day Mode 체크인 플로우)
 * 
 * ## 상태 머신 플로우
 * 1. EMOTION_SELECT: 감정 선택 (5가지 감정)
 * 2. CHATTING: AI와 대화
 * 3. TAG_SELECTION: 컨텍스트 태그 선택
 * 4. ACTION_FEEDBACK: 마이크로 액션 제안
 * 5. COMPLETED: 저장 완료
 * 
 * ## 엔드포인트 연결
 * ### generateDayModeResponse
 * - 호출: useDayCheckinMachine → gemini.ts
 * - 경로: sendMessage() → generateDayModeResponse()
 * - Firebase Functions: generateDayModeResponse (asia-northeast3)
 * - 파라미터:
 *   - userMessage: string (사용자 메시지)
 *   - history: string[] (대화 이력)
 *   - persona: CoachPersona (페르소나 설정)
 * - 응답: AI 응답 텍스트
 * - 타임아웃: 8초, 재시도: 3회
 * 
 * ## UI 구성
 * 
 * ### 1. 감정 선택 단계
 * - EmotionSelectModal 컴포넌트
 * - 5개 감정 버튼 + 강도 슬라이더
 * - 완료 후 채팅 시작
 * 
 * ### 2. 채팅 단계
 * - 메시지 목록 (사용자/AI)
 * - 입력창 + 전송 버튼
 * - QuickChip (빠른 응답)
 * - SmartContextTag (자동 태그)
 * - AIThinkingAnimation (로딩)
 * 
 * ### 3. 태그 선택 단계
 * - SmartContextTag 컴포넌트
 * - 자동 생성 태그 선택
 * - 건너뛰기 가능
 * 
 * ### 4. 마이크로 액션 단계
 * - ActionFeedback 컴포넌트
 * - 감정 기반 액션 제안
 * - 실행/건너뛰기 선택
 * 
 * ## 상태 관리
 * - 상태 머신: useDayCheckinMachine (XState 기반)
 * - 상태:
 *   - emotion: EmotionType | null
 *   - intensity: number (1-10)
 *   - messages: Message[]
 *   - input: string
 *   - tags: string[]
 *   - isAIResponding: boolean
 *   - isSaved: boolean
 * 
 * ## 위기 감지
 * - 키워드 감지: detectCrisisByKeyword()
 * - 강도 감지: emotion + intensity >= 9
 * - 패턴 감지: 최근 감정 기록 분석
 * - 감지 시: onCrisisDetected() 콜백
 * 
 * ## 저장 로직
 * - TimelineEntry 생성:
 *   - emotion, intensity
 *   - messages (대화 내용)
 *   - tags (컨텍스트)
 *   - timestamp
 * - Firestore 저장: saveConversation() + saveEmotionEntry()
 * - 동의 확인: canSaveConversation()
 * 
 * ## 사용 위치
 * - 0108mlog-0109/src/pages/chat/ChatMain.tsx
 * 
 * ## 관련 파일
 * - 상태 머신: 0108mlog-0109/src/features/checkin/useDayCheckinMachine.ts
 * - AI 서비스: 0108mlog-0109/src/services/ai/gemini.ts
 * - 위기 감지: 0108mlog-0109/src/services/crisisDetection.ts
 * - Firestore: 0108mlog-0109/src/services/firestore.ts
 * - UI:
 *   - 0108mlog-0109/src/components/ui/EmotionSelectModal.tsx
 *   - 0108mlog-0109/src/components/ui/AIThinkingAnimation.tsx
 *   - 0108mlog-0109/src/components/chat/QuickChip.tsx
 *   - 0108mlog-0109/src/components/checkin/SmartContextTag.tsx
 *   - 0108mlog-0109/src/components/actions/ActionFeedback.tsx
 * 
 * ## 위험요인
 * - ⚠️ AI 응답 지연: 타임아웃 8초, 최대 24초 소요 가능 (재시도 3회)
 *   - 개선: 스트리밍 응답 고려
 * - ⚠️ 위기 감지 정확도: 키워드 기반 한계
 *   - 오탐지 (false positive) 가능
 * - ⚠️ 상태 머신 복잡도: 5단계 플로우
 *   - 디버깅 어려움, 로깅 강화 필요
 * - ⚠️ 메모리 누수: messages 배열 무한 증가
 *   - 현재: 제한 없음, limit 검토 필요
 * - ✅ 햅틱 피드백: 모바일 UX 향상
 * - ✅ 자동 스크롤: messagesEndRef
 * - ✅ Immersive 모드: setImmersive(false) cleanup
 */
export const DayMode: React.FC<DayModeProps> = ({ 
  persona, 
  onSave, 
  setImmersive, 
  onNavigateToReports, 
  onOpenSafety, 
  onCrisisDetected, 
  onEmotionChange 
}) => {
  const { triggerHaptic } = useHaptics();
  
  // 상태 머신 훅 사용
  const machine = useDayCheckinMachine({
    persona,
    onCrisisDetected,
    onComplete: onSave,
    onEmotionChange,
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 현재 감정 설정
  const activeEmotionConfig = EMOTIONS_CONFIG.find(e => e.id === machine.emotion);

  /**
   * 메시지 목록 하단으로 스크롤
   */
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [machine.messages, machine.isAIResponding]);

  useEffect(() => {
    return () => {
      setImmersive(false);
    };
  }, [setImmersive]);

  /**
   * 감정 선택 완료 후 채팅 시작
   */
  const handleEmotionComplete = () => {
    machine.confirmEmotion();
    triggerHaptic('medium');
  };

  /**
   * 감정 선택 핸들러
   */
  const handleEmotionSelect = (emotion: EmotionType) => {
    machine.selectEmotion(emotion);
    triggerHaptic('medium');
  };

  /**
   * 강도 변경 핸들러
   */
  const handleIntensityChange = (intensity: number) => {
    machine.changeIntensity(intensity);
    triggerHaptic('light');
  };

  /**
   * 퀵칩 클릭 핸들러
   */
  const handleQuickChipClick = (text: string) => {
    machine.updateInput(text);
    inputRef.current?.focus();
    triggerHaptic('light');
  };

  /**
   * 메시지 전송 핸들러
   */
  const handleSend = async () => {
    if (!machine.input.trim()) return;
    triggerHaptic('light');
    await machine.sendMessage(machine.input);
  };

  /**
   * 체크인 완료 및 저장 핸들러
   */
  const handleFinishAndSave = async () => {
    if (machine.isSaved || machine.isActionLoading) return;
    
    if (!machine.isTagSelecting && machine.tags.length === 0) {
      machine.showTagStep();
      return;
    }
    
    setImmersive(false);
    await machine.requestSave();
  };

  /**
   * 마이크로 액션 생성 핸들러
   */
  const handleGenerateAction = async () => {
    if (!machine.emotion) return;
    await machine.generateAction();
  };

  /**
   * 액션 피드백 완료 핸들러
   */
  const handleActionFeedbackComplete = async (before: number, after: number) => {
    await machine.completeActionFeedback(before, after);
  };

  // 감정 모달이 열려있거나 감정이 선택된 상태
  const showEmotionModal = machine.isEmotionModalOpen || machine.isEmotionSelected;
  // 채팅 가능한 상태
  const showChat = machine.isChatting || machine.isAIResponding || machine.isTagSelecting || 
                   machine.isSaving || machine.isSaved || machine.isActionLoading || 
                   machine.isActionShowing || machine.isActionFeedback;
  // 퀵칩 표시 여부
  const showQuickChips = machine.isChatting && machine.messages.length > 0 && !machine.isAIResponding;

  // 인사 메시지 추가 (채팅 시작 시)
  const displayMessages = showChat && machine.messages.length === 0 
    ? [{
        id: 'greeting',
        role: 'assistant' as const,
        content: `안녕하세요! ${persona.name}입니다. ${activeEmotionConfig?.label} 기분이시군요. 어떤 이야기를 나눠볼까요?`,
        timestamp: new Date()
      }]
    : machine.messages;

  return (
    <>
      {/* 감정 선택 모달 */}
      <EmotionSelectModal
        isOpen={showEmotionModal}
        selectedEmotion={machine.emotion}
        intensity={machine.intensity}
        onEmotionSelect={handleEmotionSelect}
        onIntensityChange={handleIntensityChange}
        onComplete={handleEmotionComplete}
      />

      {/* 채팅 인터페이스 */}
      <AnimatePresence>
        {showChat && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col h-full w-full"
          >
            {/* 헤더 */}
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="flex items-center justify-between p-4 sm:p-6 border-b border-slate-200/50 bg-white/30 backdrop-blur-md"
            >
              <div className="flex items-center gap-3">
                {activeEmotionConfig && (
                  <motion.div 
                    className={`${activeEmotionConfig.color} p-2 rounded-xl bg-white/60 backdrop-blur-sm shadow-sm`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {activeEmotionConfig.icon}
                  </motion.div>
                )}
                <div>
                  <h2 className="font-bold text-lg text-slate-800">{activeEmotionConfig?.label || '감정 체크인'}</h2>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex items-center gap-1">
                      <Heart size={12} className="text-rose-400 fill-rose-400" />
                      <span className="text-xs text-slate-500">강도: {machine.intensity}/10</span>
                    </div>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500">{persona.name}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setImmersive(false)}
                className="p-2 rounded-full hover:bg-white/60 transition-colors text-slate-600"
                aria-label="닫기"
              >
                <X size={20} />
              </button>
            </motion.div>

            {/* 메시지 영역 */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 scrollbar-hide min-h-0">
              {displayMessages.map((msg, index) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <motion.div
                    className={`
                      max-w-chat-bubble sm:max-w-chat-bubble-sm rounded-lg px-4 py-3 shadow-sm
                      ${msg.role === 'user' 
                        ? 'bg-gradient-to-br from-brand-primary to-brand-secondary text-white shadow-brand-primary/20' 
                        : 'bg-white/80 backdrop-blur-md text-slate-900 border border-white/60 shadow-slate-200/50'
                      }
                    `}
                    whileHover={{ scale: 1.02 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 17 }}
                  >
                    {msg.role === 'assistant' && (
                      <div className="flex items-center gap-2 mb-1.5">
                        <div className="w-5 h-5 rounded-full bg-gradient-to-br from-brand-primary to-brand-secondary flex items-center justify-center">
                          <MessageCircle size={12} className="text-white" />
                        </div>
                        <span className="text-xs font-semibold text-brand-primary">{persona.name}</span>
                      </div>
                    )}
                    <p className={`text-sm leading-relaxed ${msg.role === 'user' ? 'text-white' : 'text-slate-800'}`}>
                      {msg.content}
                    </p>
                  </motion.div>
                </motion.div>
              ))}
              
              {machine.isAIResponding && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-sm border border-white/60 p-3">
                    <AIThinkingAnimation />
                  </div>
                </motion.div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* 퀵칩 영역 */}
            <AnimatePresence>
              {showQuickChips && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="px-4 sm:px-6 pb-2"
                >
                  <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
                    {QUICK_CHIPS.map((chip) => (
                      <QuickChip
                        key={chip.id}
                        text={chip.text}
                        onClick={() => handleQuickChipClick(chip.text)}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 액션 카드 오버레이 */}
            <AnimatePresence>
              {machine.isActionShowing && machine.action && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="p-4 sm:p-6 border-t border-slate-200/50 bg-white/30 backdrop-blur-md"
                >
                  <GlassCard className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Sparkles size={18} className="text-brand-primary" />
                          <h3 className="font-bold text-lg text-slate-800">오늘의 작은 실천</h3>
                        </div>
                        <p className="text-sm text-slate-600 leading-relaxed">{machine.action.description}</p>
                      </div>
                      <button 
                        onClick={machine.dismissAction}
                        className="p-1 rounded-full hover:bg-slate-100 transition-colors text-slate-400"
                        aria-label="액션 카드 닫기"
                      >
                        <X size={18} />
                      </button>
                    </div>
                    <Button 
                      variant="primary" 
                      className="w-full"
                      onClick={machine.startActionFeedback}
                      aria-label={`${machine.action.title} 시도해보기`}
                    >
                      시도해보기 ({machine.action.duration})
                    </Button>
                  </GlassCard>
                </motion.div>
              )}
              
              {/* Before/After 피드백 오버레이 */}
              {machine.isActionFeedback && machine.action && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="p-4 sm:p-6 border-t border-slate-200/50 bg-white/30 backdrop-blur-md"
                >
                  <ActionFeedback
                    actionTitle={machine.action.title}
                    onComplete={handleActionFeedbackComplete}
                    onSkip={machine.skipAction}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* 태그 입력 단계 */}
            {machine.isTagSelecting && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 sm:p-6 border-t border-slate-200/50 bg-white/40 backdrop-blur-md"
              >
                <SmartContextTag
                  onTagsChange={machine.updateTags}
                  initialTags={machine.tags}
                  locationPermission="granted"
                />
                <div className="flex gap-2 mt-4">
                  <Button
                    onClick={handleFinishAndSave}
                    variant="primary"
                    className="flex-1"
                    aria-label="체크인 완료 및 저장"
                  >
                    저장하기
                  </Button>
                  <Button
                    onClick={handleFinishAndSave}
                    variant="ghost"
                  >
                    스킵
                  </Button>
                </div>
              </motion.div>
            )}

            {/* 입력 영역 */}
            {machine.isChatting && !machine.isTagSelecting && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 sm:p-6 border-t border-slate-200/50 bg-white/40 backdrop-blur-md"
              >
                <div className="flex gap-2 mb-3">
                  <div className="flex-1 relative">
                    <input
                      ref={inputRef}
                      type="text"
                      value={machine.input}
                      onChange={(e) => machine.updateInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                      placeholder="무엇이든 편하게 말씀해주세요..."
                      className="w-full px-4 py-3 pr-12 rounded-full bg-white/80 backdrop-blur-sm border border-slate-200/60 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 focus:border-brand-primary/50 text-slate-800 placeholder-slate-400 transition-all"
                      aria-label="메시지 입력"
                    />
                    <button
                      onClick={handleSend}
                      disabled={!machine.input.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-brand-primary text-white hover:bg-brand-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm hover:shadow-md"
                      aria-label="전송"
                    >
                      <Send size={16} />
                    </button>
                  </div>
                </div>
                
                {/* 완료 및 액션 버튼 */}
                <div className="flex gap-2">
                  <Button 
                    onClick={handleFinishAndSave}
                    variant="secondary"
                    className="flex-1"
                    disabled={machine.isSaved}
                    aria-label="체크인 완료 및 저장"
                  >
                    {machine.isSaved ? '저장 완료 ✓' : '대화 마무리'}
                  </Button>
                  <Button 
                    onClick={handleGenerateAction}
                    variant="ghost"
                    isLoading={machine.isActionLoading}
                    className="px-4"
                    aria-label="마이크로 액션 생성"
                    title="오늘의 작은 실천 추천받기"
                  >
                    <Sparkles size={18} className={machine.isActionLoading ? 'animate-pulse' : ''} />
                  </Button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
