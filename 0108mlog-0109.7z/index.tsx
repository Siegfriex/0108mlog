/**
 * 마음로그 V5.0 애플리케이션 엔트리 포인트
 * 
 * ## 위치 및 역할
 * - 파일: 0108mlog-0109/index.tsx
 * - 역할: React 앱 초기화 및 DOM 마운트
 * 
 * ## 초기화 순서
 * 1. DOM 루트 엘리먼트 확인 (#root)
 * 2. React 18 createRoot API로 루트 생성
 * 3. StrictMode 래핑으로 개발 모드 이중 렌더링 (잠재적 문제 감지)
 * 4. AppRouter 마운트 → Provider 계층 구조 초기화
 * 
 * ## Provider 계층 구조 (AppRouter 내부)
 * ```
 * ErrorBoundary
 *   └─ AppProvider (전역 상태: mode, persona, timeline, emotion)
 *       └─ UIProvider (UI 상태: immersive, loading 등)
 *           └─ BrowserRouter (React Router)
 *               └─ OnboardingGuard (온보딩 완료 여부 체크)
 *                   └─ Routes
 * ```
 * 
 * ## 관련 파일
 * - 라우터: 0108mlog-0109/src/router/Router.tsx
 * - 스타일: 0108mlog-0109/src/index.css (Tailwind + CSS 변수)
 * 
 * ## 위험요인
 * - ✅ 루트 엘리먼트 존재 체크 완료
 * - ✅ StrictMode로 이중 렌더링 감지 활성화
 * - ⚠️ 에러 발생 시 앱 전체 크래시 (ErrorBoundary는 AppRouter 내부)
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import { AppRouter } from './src/router/Router';
import './src/index.css';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <AppRouter />
  </React.StrictMode>
);